<?php
// contact.php - ទំព័រទំនាក់ទំនង (កំណែ FUN STYLE)

// រួមបញ្ចូលការតភ្ជាប់មូលដ្ឋានទិន្នន័យ
include 'database.php';

// ចាប់ផ្តើម session ប្រសិនបើវាមិនទាន់បានចាប់ផ្តើម
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ពិនិត្យមើលថាអ្នកប្រើប្រាស់ជាអ្នកគ្រប់គ្រងឬអត់ (សម្រាប់ Menu)
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
$current_page = basename(__FILE__); // Get the current script name (contact.php)

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // ពិនិត្យមើលថា fields ទាំងអស់ត្រូវបានកំណត់
    if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['message'])) {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $message = trim($_POST['message']);

        // ពិនិត្យមើលថា fields មិនទទេ
        if (!empty($name) && !empty($email) && !empty($message)) {
            // ពិនិត្យ email format
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                // រៀបចំ statement ដើម្បីការពារ SQL Injection
                $stmt = $conn->prepare("INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)");
                
                if ($stmt) {
                    $stmt->bind_param("sss", $name, $email, $message);
                    if ($stmt->execute()) {
                        $success_message = "សាររបស់អ្នកត្រូវបានផ្ញើដោយជោគជ័យ។ យើងនឹងទាក់ទងទៅអ្នកវិញក្នុងពេលឆាប់ៗនេះ!";
                        // Clear form fields after successful submission
                        $name = $email = $message = '';
                    } else {
                        $error_message = "មានបញ្ហាក្នុងការផ្ញើសារ។ សូមព្យាយាមម្តងទៀត។";
                    }
                    $stmt->close();
                } else {
                    $error_message = 'មានបញ្ហាក្នុងការរៀបចំសំណួរ៖ ' . htmlspecialchars($conn->error);
                }
            } else {
                $error_message = 'សូមបញ្ចូលអ៊ីមែលដែលត្រឹមត្រូវ។';
            }
        } else {
            $error_message = 'សូមបំពេញគ្រប់ fields ទាំងអស់។';
        }
    } else {
        $error_message = 'ទម្រង់មិនត្រឹមត្រូវ។';
    }
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ទំនាក់ទំនង - MODERN SHOP8</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --card-background: #ffffff;
            --border-radius: 8px;
            --shadow-light: 0 4px 6px rgba(0,0,0,0.1);
            --shadow-heavy: 0 8px 15px rgba(0,0,0,0.2);
            --text-color: #333;
            --light-text-color: #666;
            --error-color: #e63946;
        }
        
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif; 
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: var(--text-color);
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* ======================================= */
        /* --- HEADER & NAVIGATION STYLES --- */
        /* ======================================= */
        header {
            background-color: var(--primary-color);
            padding: 15px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        header .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 90%;
            max-width: 1200px;
            margin: auto;
            flex-wrap: wrap; 
        }
        .brand-logo {
            display: flex; align-items: center; gap: 10px; order: 1;
        }
        .brand-logo img {
            height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px;
        }
        .brand-text {
            display: flex; flex-direction: column; color: #fff; line-height: 1.2;
        }
        .brand-text h1 {
            font-size: 1.5em; margin: 0; font-weight: bold;
        }
        .brand-text p {
            font-size: 0.8em; margin: 0; opacity: 0.8;
        }
        header .navbar ul {
            list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; order: 3; width: 100%; justify-content: flex-end;
        }
        header .navbar ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header .navbar ul li a:hover,
        header .navbar ul li.active-link a {
            color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle {
            display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2;
        }
        /* Mobile Menu */
        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            header .navbar ul { display: none; flex-direction: column; order: 4; background-color: #005660; }
            header .navbar ul.open { display: flex; }
            .brand-logo { flex-direction: column; align-items: flex-start; gap: 2px; }
        }

        /* ======================================= */
        /* --- CONTACT PAGE FUN STYLE --- */
        /* ======================================= */
        .main-content {
            min-height: calc(100vh - 200px);
            padding: 20px 0;
        }
        
        .contact-form-container {
            max-width: 600px;
            margin: 30px auto;
            padding: 40px;
            background-color: var(--card-background);
            border-radius: 15px; /* Fun: More rounded */
            box-shadow: 0 10px 20px rgba(0,0,0,0.15); /* Fun: Stronger shadow */
            border: 2px solid var(--secondary-color); /* Fun: Highlight border */
        }
        
        .contact-form-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary-color);
            font-size: 2.2em;
            border-bottom: 3px solid var(--secondary-color);
            padding-bottom: 10px;
        }
        
        .form-group {
            margin-bottom: 20px;
            position: relative;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: var(--primary-color); /* Fun: Highlight labels */
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd; /* Fun: Slightly thicker border */
            border-radius: 10px; /* Fun: More rounded inputs */
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--secondary-color); /* Fun: Focus highlight */
            box-shadow: 0 0 8px rgba(255, 209, 102, 0.5); /* Fun: Yellow glow */
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }
        
        .btn-submit {
            width: 100%;
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 15px;
            font-size: 1.2em; /* Larger button */
            cursor: pointer;
            border-radius: 50px; /* Fun: Pill shape */
            transition: background-color 0.3s ease, transform 0.2s ease;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .btn-submit:hover {
            background-color: var(--secondary-color);
            color: var(--primary-color); /* Fun: Text color change */
            transform: translateY(-3px); /* Fun: Lift effect */
        }
        
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 10px; 
            text-align: center;
            font-weight: bold;
            border: 2px solid; /* Stronger message border */
            animation: fadeIn 0.5s ease-out;
        }
        
        .success-message {
            background-color: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        
        .error-message {
            background-color: #f8d7da;
            color: var(--error-color);
            border-color: #f5c6cb;
        }
        
        .contact-info {
            max-width: 600px;
            margin: 30px auto;
            padding: 30px;
            background-color: var(--card-background);
            border-radius: 15px;
            box-shadow: var(--shadow-light);
            text-align: center;
            border-top: 5px solid var(--primary-color);
        }
        
        .contact-info h3 {
            color: var(--primary-color);
            margin-bottom: 15px;
            font-size: 1.5em;
        }
        
        .contact-info p {
            margin: 10px 0;
            color: var(--text-color);
            font-size: 1.1em;
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .contact-form-container { margin: 20px; padding: 30px 20px; }
            .contact-info { margin: 20px; padding: 20px; }
            .contact-form-container h2 { font-size: 1.8em; }
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            
            <!-- Logo area -->
            <div class="brand-logo">
                <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
                <div class="brand-text">
                    <h1>MODERN SHOP8</h1>
                    <p>ហាងលក់ទំនិញទំនើបសម្រាប់អ្នក!</p> 
                </div>
            </div>
            
            <!-- Hamburger Icon -->
            <div class="menu-toggle" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>

            <!-- Navigation Menu -->
            <nav>
                <ul id="main-menu">
                    <li class="<?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>"><a href="index.php">ទំព័រដើម</a></li>
                    <li class="<?php echo ($current_page == 'cart.php') ? 'active-link' : ''; ?>"><a href="cart.php">រទេះទិញទំនិញ</a></li>
                    <li class="<?php echo ($current_page == 'history.php') ? 'active-link' : ''; ?>"><a href="history.php">ប្រវត្តិការទិញ</a></li>
                    <li class="<?php echo ($current_page == 'contact.php') ? 'active-link' : ''; ?>"><a href="contact.php">ទំនាក់ទំនង</a></li>
                    
                    <?php if ($is_admin): ?>
                        <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                        <li><a href="logout.php">ចាកចេញ</a></li>
                    <?php else: ?>
                        <li class="<?php echo ($current_page == 'admin_login.php') ? 'active-link' : ''; ?>"><a href="admin_login.php">ចូលជាអ្នកគ្រប់គ្រង</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="main-content">
        <div class="contact-form-container">
            <h2><i class="fas fa-paper-plane" style="color: var(--secondary-color);"></i> ទំនាក់ទំនងមកយើង</h2>
            
            <?php if ($success_message): ?>
                <div class="message success-message">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error_message): ?>
                <div class="message error-message">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>
            
            <form action="contact.php" method="POST">
                <div class="form-group">
                    <label for="name"><i class="fas fa-user"></i> ឈ្មោះ:</label>
                    <input type="text" id="name" name="name" value="<?php echo isset($name) ? htmlspecialchars($name) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> អ៊ីមែល:</label>
                    <input type="email" id="email" name="email" value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="message"><i class="fas fa-comment"></i> សារ:</label>
                    <textarea id="message" name="message" rows="6" required><?php echo isset($message) ? htmlspecialchars($message) : ''; ?></textarea>
                </div>
                
                <button type="submit" class="btn-submit"><i class="fas fa-share"></i> ផ្ញើសារ</button>
            </form>
        </div>
        
        <div class="contact-info">
            <h3><i class="fas fa-info-circle"></i> ព័ត៌មានទំនាក់ទំនង</h3>
            <p>
                <i class="fas fa-map-marker-alt" style="color: var(--primary-color);"></i> <strong>អាសយដ្ឋាន៖</strong> ផ្ទះលេខ ៨, មហាវិថី ២១៥, រាជធានីភ្នំពេញ
            </p>
            <p>
                <i class="fas fa-phone" style="color: var(--primary-color);"></i> <strong>ទូរស័ព្ទ៖</strong> +៨៥៥ ១២ ៣៤៥ ៦៧៨
            </p>
            <p>
                <i class="fas fa-at" style="color: var(--primary-color);"></i> <strong>អ៊ីមែល៖</strong> info@modernshop8.com
            </p>
            <p>
                <i class="fas fa-clock" style="color: var(--primary-color);"></i> <strong>ម៉ោងបើក៖</strong> ច័ន្ទ-សៅរ៍ ៨:០០AM - ៦:០០PM
            </p>
        </div>
    </div>

    <footer>
        <div class="container">
            &copy; <?php echo date("Y"); ?> MODERN SHOP8. រក្សាសិទ្ធិគ្រប់យ៉ាង។
        </div>
    </footer>
    
    <!-- JavaScript for mobile menu toggle (required for responsiveness) -->
    <script>
        function toggleMenu() {
            var menu = document.getElementById('main-menu');
            menu.classList.toggle('open');
        }
    </script>
</body>
</html>

<?php
// បិទការតភ្ជាប់បន្ទាប់ពីការដំណើរការ script ទាំងមូល
if (isset($conn)) {
    $conn->close();
}
?>