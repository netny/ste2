<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>អំពីយើង - MODERN SHOP8</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Khmer:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #1abc9c;
            --text-color: #333;
            --light-text-color: #777;
            --card-background: #ffffff;
            --shadow-light: 0 4px 6px rgba(0, 0, 0, 0.1);
            --shadow-heavy: 0 10px 20px rgba(0, 0, 0, 0.15);
            --border-radius: 8px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Noto Sans Khmer', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: var(--text-color);
            line-height: 1.6;
        }

        /* --- Navigation Menu --- */
        .navbar {
            background-color: #0d4858;
            box-shadow: var(--shadow-heavy);
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 1000;
        }

        .nav-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
            height: 70px;
        }

        .logo {
            font-size: 1.8rem;
            font-weight: bold;
            color: #00f2ff;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo span {
            color: #ffffff;
        }

        .logo i {
            font-size: 2rem;
        }

        /* Desktop Navigation */
        .nav-links {
            display: flex;
            list-style: none;
            align-items: center;
            margin: 0;
            padding: 0;
        }

        .nav-links li {
            position: relative;
        }

        .nav-links a {
            text-decoration: none;
            color: #ffffff;
            font-weight: 600;
            padding: 1rem 1.2rem;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            border-radius: 5px;
            margin: 0 2px;
        }

        .nav-links a i {
            font-size: 1.1rem;
            width: 20px;
            text-align: center;
        }

        .nav-links a:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: #00f2ff;
            transform: translateY(-2px);
        }

        .nav-links a.active {
            background-color: rgba(0, 242, 255, 0.2);
            color: #00f2ff;
            border-bottom: 3px solid #00f2ff;
        }

        /* Mobile Menu Toggle */
        .menu-toggle {
            display: none;
            flex-direction: column;
            cursor: pointer;
            padding: 5px;
        }

        .menu-toggle span {
            width: 25px;
            height: 3px;
            background: #ffffff;
            margin: 3px 0;
            transition: 0.3s;
            border-radius: 2px;
        }

        /* Mobile Navigation */
        @media (max-width: 1024px) {
            .nav-container {
                padding: 0 1rem;
            }

            .nav-links a {
                padding: 0.8rem 1rem;
                font-size: 0.9rem;
            }

            .nav-links a i {
                font-size: 1rem;
            }
        }

        @media (max-width: 768px) {
            .menu-toggle {
                display: flex;
            }

            .nav-links {
                position: fixed;
                top: 70px;
                left: -100%;
                width: 280px;
                height: calc(100vh - 70px);
                background: #0d4858;
                flex-direction: column;
                align-items: flex-start;
                padding: 2rem 0;
                transition: left 0.3s ease;
                box-shadow: var(--shadow-heavy);
                border-top: 1px solid rgba(255, 255, 255, 0.1);
            }

            .nav-links.active {
                left: 0;
            }

            .nav-links li {
                width: 100%;
                margin: 0;
            }

            .nav-links a {
                padding: 1rem 2rem;
                width: 100%;
                border-radius: 0;
                margin: 0;
                border-left: 4px solid transparent;
                font-size: 1rem;
            }

            .nav-links a.active {
                border-left: 4px solid #00f2ff;
                border-bottom: none;
                background-color: rgba(0, 242, 255, 0.15);
            }

            .nav-links a:hover {
                background-color: rgba(255, 255, 255, 0.05);
                border-left: 4px solid #00f2ff;
                transform: none;
            }

            .logo {
                font-size: 1.5rem;
            }

            .logo i {
                font-size: 1.7rem;
            }
        }

        @media (max-width: 480px) {
            .nav-container {
                padding: 0 0.8rem;
                height: 60px;
            }

            .nav-links {
                top: 60px;
                height: calc(100vh - 60px);
                width: 250px;
            }

            .logo {
                font-size: 1.3rem;
            }

            .logo i {
                font-size: 1.5rem;
            }
        }

        /* Menu toggle animation */
        .menu-toggle.active span:nth-child(1) {
            transform: rotate(-45deg) translate(-5px, 6px);
        }

        .menu-toggle.active span:nth-child(2) {
            opacity: 0;
        }

        .menu-toggle.active span:nth-child(3) {
            transform: rotate(45deg) translate(-5px, -6px);
        }

        /* --- About Page Content Styles --- */
        .about-container {
            max-width: 1200px;
            margin: 50px auto;
            padding: 0 20px;
        }

        .about-header {
            text-align: center;
            margin-bottom: 50px;
            background: #ffffff;
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
        }

        .about-header h1 {
            color: var(--primary-color);
            font-size: 3em;
            margin-bottom: 20px;
            border-bottom: 3px solid var(--secondary-color);
            display: inline-block;
            padding-bottom: 10px;
        }

        .about-header p {
            font-size: 1.2em;
            color: var(--text-color);
            max-width: 800px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* Mission & Vision Section */
        .mission-vision {
            display: flex;
            gap: 30px;
            margin-bottom: 60px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .mission-card, .vision-card {
            background: var(--card-background);
            flex: 1;
            min-width: 300px;
            padding: 30px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-heavy);
            text-align: center;
            transition: transform 0.3s ease;
            border-top: 5px solid var(--secondary-color);
        }

        .mission-card:hover, .vision-card:hover {
            transform: translateY(-5px);
        }

        .card-icon {
            font-size: 3em;
            color: var(--secondary-color);
            margin-bottom: 15px;
        }

        .mission-card h2, .vision-card h2 {
            color: var(--primary-color);
            margin-bottom: 15px;
            font-size: 1.8em;
        }

        .mission-card p, .vision-card p {
            color: var(--light-text-color);
        }

        /* Stats Section */
        .stats-section {
            text-align: center;
            margin-bottom: 60px;
            padding: 30px 0;
            background: #e9ecef;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
        }

        .stats-section h2 {
            color: var(--primary-color);
            margin-bottom: 30px;
            font-size: 2em;
        }

        .stats-grid {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            gap: 20px;
            max-width: 900px;
            margin: 0 auto;
        }

        .stat-box {
            background: var(--card-background);
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            min-width: 180px;
            flex: 1;
        }

        .stat-box .number {
            font-size: 2.5em;
            font-weight: bold;
            color: var(--accent-color);
            margin-bottom: 5px;
        }

        .stat-box .label {
            color: var(--primary-color);
            font-weight: 600;
        }

        /* Team Section */
        .team-section {
            text-align: center;
            margin-bottom: 60px;
            padding: 30px 0;
        }

        .team-section h2 {
            color: var(--primary-color);
            margin-bottom: 40px;
            font-size: 2.5em;
            border-bottom: 2px solid var(--secondary-color);
            display: inline-block;
            padding-bottom: 5px;
        }

        .team-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            justify-content: center;
        }

        .team-member {
            background: var(--card-background);
            width: 250px;
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-heavy);
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .team-member:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }

        .member-img-container {
            width: 150px;
            height: 150px;
            margin: 0 auto 15px;
            border-radius: 50%;
            overflow: hidden;
            border: 5px solid var(--secondary-color);
        }

        .member-img-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .member-img-container .fallback-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
            font-size: 4em;
            color: white;
        }
        
        .member-img-container.net-1 .fallback-icon {
            background-color: #3498db;
        }
        
        .member-img-container.net-2 .fallback-icon {
            background-color: #e74c3c;
        }
        
        .member-img-container.net-3 .fallback-icon {
            background-color: #2ecc71;
        }
        
        .member-img-container.net-4 .fallback-icon {
            background-color: #f39c12;
        }

        .team-member h3 {
            color: var(--primary-color);
            margin-bottom: 5px;
            font-size: 1.4em;
        }

        .team-member p.position {
            color: var(--secondary-color);
            font-weight: bold;
            margin-bottom: 10px;
        }

        .team-member p.description {
            color: var(--light-text-color);
            font-size: 0.9em;
        }
        
        /* Values Section */
        .values-section {
            margin-bottom: 60px;
            padding: 30px 0;
        }
        
        .values-section h2 {
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 40px;
            font-size: 2.5em;
        }
        
        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
        }
        
        .value-card {
            background: var(--card-background);
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            text-align: center;
            transition: transform 0.3s ease;
        }
        
        .value-card:hover {
            transform: translateY(-5px);
        }
        
        .value-icon {
            font-size: 2.5em;
            color: var(--secondary-color);
            margin-bottom: 15px;
        }
        
        .value-card h3 {
            color: var(--primary-color);
            margin-bottom: 10px;
        }
        
        .value-card p {
            color: var(--light-text-color);
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .mission-vision {
                flex-direction: column;
                gap: 20px;
            }

            .mission-card, .vision-card {
                min-width: 90%;
            }

            .stats-grid {
                grid-template-columns: 1fr 1fr;
                gap: 15px;
            }

            .stat-box {
                min-width: auto;
                flex: none;
                width: 45%;
            }

            .team-grid {
                flex-direction: column;
                align-items: center;
            }

            .team-member {
                width: 90%;
                max-width: 350px;
            }
            
            .values-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Back to Home Button */
        .back-home-btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background: var(--primary-color);
            color: white;
            padding: 12px 25px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            margin-top: 30px;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-light);
        }

        .back-home-btn:hover {
            background: var(--secondary-color);
            transform: translateY(-3px);
            box-shadow: var(--shadow-heavy);
        }

        /* Footer */
        footer {
            background-color: var(--primary-color);
            color: white;
            padding: 30px 0;
            text-align: center;
            margin-top: 50px;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .social-icons {
            margin-bottom: 20px;
        }

        .social-icons a {
            color: white;
            font-size: 1.5rem;
            margin: 0 10px;
            transition: color 0.3s;
        }

        .social-icons a:hover {
            color: #00f2ff;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-store"></i>
                MODERN <span>SHOP8</span>
            </div>
            
            <div class="menu-toggle" id="mobile-menu">
                <span></span>
                <span></span>
                <span></span>
            </div>

            <ul class="nav-links" id="nav-links">
                <li><a href="index.php"><i class="fas fa-home"></i>ទំព័រដើម</a></li>
                <li><a href="about.php" class="active"><i class="fas fa-info-circle"></i>អំពីយើង</a></li>
                <li><a href="cart.php"><i class="fas fa-shopping-cart"></i>រទេះទិញទំនិញ</a></li>
                <li><a href="history.php"><i class="fas fa-history"></i>ប្រវត្តិការទិញ</a></li>
                <li><a href="contact.php"><i class="fas fa-phone"></i>ទំនាក់ទំនង</a></li>
                <li><a href="admin.php"><i class="fas fa-cog"></i>ផ្ទាំងគ្រប់គ្រង</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i>ចាកចេញ</a></li>
            </ul>
        </div>
    </nav>

    <div class="about-container">
        <div class="about-header">
            <h1><i class="fas fa-info-circle"></i> អំពីយើង</h1>
            <p>
                MODERN SHOP8 គឺជាហាងអនឡាញដែលទំនើប និងគួរឱ្យទុកចិត្តបំផុតនៅក្នុងប្រទេសកម្ពុជា។ 
                យើងផ្តល់នូវផលិតផលដែលមានគុណភាពខ្ពស់ សេវាកម្មដ៏ល្អ និងតម្លៃសមរម្យ។
            </p>
            <a href="index.php" class="back-home-btn">
                <i class="fas fa-home"></i> ត្រឡប់ទៅផ្ទះ
            </a>
        </div>

        <div class="mission-vision">
            <div class="mission-card">
                <div class="card-icon">
                    <i class="fas fa-bullseye"></i>
                </div>
                <h2>បេសកកម្មរបស់យើង</h2>
                <p>
                    ផ្តល់នូវបទពិសោធន៍ទិញទំនិញអនឡាញដ៏ល្អបំផុតដល់អតិថិជន 
                    តាមរយៈផលិតផលដែលមានគុណភាពខ្ពស់ តម្លៃសមរម្យ 
                    និងសេវាកម្មដ៏ល្អឥតខ្ចោះ។
                </p>
            </div>

            <div class="vision-card">
                <div class="card-icon">
                    <i class="fas fa-eye"></i>
                </div>
                <h2>ចក្ខុវិស័យរបស់យើង</h2>
                <p>
                    ក្លាយជាហាងអនឡាញឈានមុខគេនៅក្នុងតំបន់ 
                    ដោយការផ្តល់នូវភាពងាយស្រួល និងបទពិសោធន៍ទិញទំនិញ 
                    ដ៏ទំនើបសម្រាប់អតិថិជនរបស់យើង។
                </p>
            </div>
        </div>

        <div class="stats-section">
            <h2>ស្ថិតិសំខាន់ៗ</h2>
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="number">5,000+</div>
                    <div class="label">ផលិតផល</div>
                </div>
                <div class="stat-box">
                    <div class="number">10,000+</div>
                    <div class="label">អតិថិជន</div>
                </div>
                <div class="stat-box">
                    <div class="number">99%</div>
                    <div class="label">ការពេញចិត្ត</div>
                </div>
                <div class="stat-box">
                    <div class="number">12+</div>
                    <div class="label">ឆ្នាំនៃបទពិសោធន៍</div>
                </div>
            </div>
        </div>
        
        <div class="values-section">
            <h2>តម្លៃរបស់យើង</h2>
            <div class="values-grid">
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-medal"></i>
                    </div>
                    <h3>គុណភាព</h3>
                    <p>យើងតែងតែផ្តល់នូវផលិតផលដែលមានគុណភាពខ្ពស់បំផុតដល់អតិថិជន</p>
                </div>
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-handshake"></i>
                    </div>
                    <h3>ទំនុកចិត្ត</h3>
                    <p>ភាពទុកចិត្តរបស់អតិថិជនគឺជាអាទិភាពរបស់យើង</p>
                </div>
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-lightbulb"></i>
                    </div>
                    <h3>ការច្នៃប្រឌិត</h3>
                    <p>យើងបន្តអភិវឌ្ឍន៍ និងធ្វើឱ្យប្រសើរឡើងនូវសេវាកម្មរបស់យើង</p>
                </div>
                <div class="value-card">
                    <div class="value-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3>សហការ</h3>
                    <p>ការធ្វើការជាក្រុមជាមួយសមាជិកក្រុម និងដៃគូរបស់យើង</p>
                </div>
            </div>
        </div>

        <div class="team-section">
            <h2>ក្រុមការងារ CEO Top Cam </h2>
            <div class="team-grid">
                <div class="team-member">
                    <div class="member-img-container net-1">
                        <div class="fallback-icon">
                            <img src="../img/NET.jpg" alt="NET">
                        </div>
                    </div>
                    <h3>Mr.NY NET</h3>
                    <p class="position">អ្នកគ្រប់គ្រង</p>
                    <p class="description">មានបទពិសោធន៍ជាង 5 ឆ្នាំក្នុងវិស័យពាណិជ្ជកម្ម</p>
                </div>
               <div class="team-member">
                    <div class="member-img-container net-1">
                        <div class="fallback-icon">
                            <img src="../img/mesa.jpg" alt="NET">
                        </div>
                    </div>
                    <h3>Mr.KVAV Mesa</h3>
                    <p class="position">អ្នកត្រូតពិនិត្យ</p>
                    <p class="description">មានបទពិសោធន៍ជាង 5 ឆ្នាំក្នុងវិស័យពាណិជ្ជកម្ម</p>
                </div>
                <div class="team-member">
                    <div class="member-img-container net-1">
                        <div class="fallback-icon">
                            <img src="../img/senin.jpg" alt="NET">
                        </div>
                    </div>
                    <h3>Mr.ANG SiNiN</h3>
                    <p class="position">អ្នកគ្រប់គ្រងប្រតិបត្តិការ</p>
                    <p class="description">មានបទពិសោធន៍ជាង 5 ឆ្នាំក្នុងវិស័យពាណិជ្ជកម្ម</p>
                </div>
                <div class="team-member">
                    <div class="member-img-container net-1">
                        <div class="fallback-icon">
                            <img src="../img/moni.jpg" alt="NET">
                        </div>
                    </div>
                    <h3>Mrs.RUON Bulimunny</h3>
                    <p class="position">អ្នកគ្រប់គ្រងទីផ្សារ</p>
                    <p class="description">មានបទពិសោធន៍ជាង 5 ឆ្នាំក្នុងវិស័យពាណិជ្ជកម្ម</p>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-telegram"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
            <p>&copy; 2023 MODERN SHOP8. រក្សាសិទ្ធិគ្រប់យ៉ាង។</p>
        </div>
    </footer>

    <script>
        // Mobile menu toggle
        const mobileMenu = document.getElementById('mobile-menu');
        const navLinks = document.getElementById('nav-links');

        mobileMenu.addEventListener('click', () => {
            mobileMenu.classList.toggle('active');
            navLinks.classList.toggle('active');
        });

        // Close mobile menu when clicking on a link
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', () => {
                mobileMenu.classList.remove('active');
                navLinks.classList.remove('active');
            });
        });

        // Close mobile menu when clicking outside
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.nav-container') && navLinks.classList.contains('active')) {
                mobileMenu.classList.remove('active');
                navLinks.classList.remove('active');
            }
        });

        // Intersection Observer for scroll animations
        const observerOptions = {
            threshold: 0.2, // Trigger when 20% of the element is visible
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Prepare elements for animation and observe them
        document.addEventListener('DOMContentLoaded', () => {
            const elementsToAnimate = [
                ...document.querySelectorAll('.stat-box'),
                ...document.querySelectorAll('.team-member'),
                ...document.querySelectorAll('.value-card'),
                document.querySelector('.mission-card'),
                document.querySelector('.vision-card')
            ].filter(el => el); // Filter out nulls if elements are not found

            elementsToAnimate.forEach(el => {
                el.style.opacity = '0';
                el.style.transform = 'translateY(20px)';
                el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
                observer.observe(el);
            });
        });
    </script>
</body>
</html>