<?php
// product.php - ទំព័រលម្អិតផលិតផលដែលមានមុខងារ 'បន្ថែមទៅក្នុងរទេះ' (FUN STYLE)

// រួមបញ្ចូលការតភ្ជាប់មូលដ្ឋានទិន្នន័យ (database.php នឹងចាប់ផ្តើម session និង $conn)
include 'database.php';

// Get the current script name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']); 
// Check admin status for menu.php (if needed)
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];

$product = null;
$error_message = '';

// ពិនិត្យមើលថាតើលេខសម្គាល់ផលិតផលត្រូវបានផ្តល់ឱ្យ
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        $error_message = "រកមិនឃើញផលិតផលទេ។";
    }
    $stmt->close();
} else {
    $error_message = "លេខសម្គាល់ផលិតផលមិនត្រឹមត្រូវទេ។";
}

// គ្រប់គ្រងការបន្ថែមទៅក្នុងរទេះ
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    if ($product) {
        $quantity = isset($_POST['quantity']) && is_numeric($_POST['quantity']) ? intval($_POST['quantity']) : 1;

        // បន្ថែមឬ update ផលិតផលទៅក្នុងរទេះ session
        if (isset($_SESSION['cart'][$product['id']])) {
            $_SESSION['cart'][$product['id']]['quantity'] += $quantity;
        } else {
            $_SESSION['cart'][$product['id']] = [
                'name' => $product['name'],
                'price' => $product['price'],
                'quantity' => $quantity
            ];
        }
        
        // Redirect ទៅកាន់ទំព័ររទេះទិញទំនិញ
        header('Location: cart.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>លម្អិតផលិតផល - MODERN SHOP8</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --card-background: #ffffff;
            --border-radius: 8px;
            --shadow-heavy: 0 10px 30px rgba(0,0,0,0.15);
            --text-color: #333;
            --light-text-color: #666;
            --button-primary: var(--primary-color);
            --button-hover: var(--secondary-color);
        }
        
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif; 
            background-color: #f4f4f9;
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* ======================================= */
        /* --- HEADER & NAVIGATION (FUN/RESPONSIVE) --- */
        /* ======================================= */
        header { background-color: var(--primary-color); padding: 15px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        header .navbar {
            display: flex; justify-content: space-between; align-items: center; width: 90%; max-width: 1200px; margin: auto; flex-wrap: wrap; 
        }
        .brand-logo { display: flex; align-items: center; gap: 10px; order: 1; }
        .brand-logo img { height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px; }
        .brand-text { display: flex; flex-direction: column; color: #fff; line-height: 1.2; }
        .brand-text h1 { font-size: 1.5em; margin: 0; font-weight: bold; }
        .brand-text p { font-size: 0.8em; margin: 0; opacity: 0.8; }
        header nav ul {
            list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; order: 3; width: 100%; justify-content: flex-end;
        }
        header nav ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header nav ul li a:hover,
        header nav ul li.active-link a {
            color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle { display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2; }
        
        /* Mobile Menu */
        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            header .navbar ul { display: none; flex-direction: column; order: 4; background-color: #005660; }
            header .navbar ul.open { display: flex; }
            .brand-logo { flex-direction: column; align-items: flex-start; gap: 2px; }
        }

        /* ======================================= */
        /* --- PRODUCT DETAIL FUN STYLE --- */
        /* ======================================= */
        .product-detail {
            display: flex;
            gap: 40px;
            margin: 50px auto;
            padding: 40px;
            background-color: var(--card-background);
            border-radius: 15px;
            box-shadow: var(--shadow-heavy);
            align-items: flex-start;
        }

        .product-detail img {
            width: 45%;
            max-width: 450px;
            height: auto;
            border-radius: 10px;
            object-fit: cover;
            border: 5px solid var(--secondary-color); 
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .product-info {
            width: 55%;
            padding-top: 10px;
        }

        .product-info h2 {
            font-size: 2.2em;
            color: var(--primary-color);
            border-bottom: 3px solid var(--secondary-color);
            padding-bottom: 10px;
            margin-top: 0;
            margin-bottom: 20px;
        }

        .product-info .description {
            font-size: 1.1em;
            line-height: 1.6;
            color: var(--text-color);
            margin-bottom: 30px;
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
        }

        .product-info .price {
            font-size: 2em;
            font-weight: bold;
            color: var(--secondary-color);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .product-info .price i {
            color: var(--primary-color);
        }

        /* Form Styling */
        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
            color: var(--primary-color);
        }

        .form-group input[type="number"] {
            width: 100px;
            padding: 10px;
            border: 2px solid #ddd;
            border-radius: 8px;
            text-align: center;
            font-size: 1.1em;
            transition: border-color 0.3s;
        }
        .form-group input[type="number"]:focus {
            border-color: var(--secondary-color);
        }

        .product-info .btn {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            background-color: var(--button-primary);
            color: white;
            border: none;
            padding: 15px 30px;
            font-size: 1.2em;
            cursor: pointer;
            border-radius: 50px; 
            font-weight: bold;
            margin-top: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
            text-decoration: none;
        }
        .product-info .btn:hover {
            background-color: var(--button-hover);
            color: var(--primary-color);
            transform: translateY(-3px) scale(1.02); 
            box-shadow: 0 6px 10px rgba(0,0,0,0.2);
        }
        
        /* Error Message Style */
        .error-message-box {
            background-color: #f8d7da;
            color: #721c24;
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #f5c6cb;
            margin: 50px auto;
            max-width: 600px;
            text-align: center;
            font-weight: bold;
        }

        /* Responsive adjustments */
        @media (max-width: 900px) {
            .product-detail {
                flex-direction: column;
                gap: 20px;
                padding: 30px;
            }
            .product-detail img, .product-info {
                width: 100%;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container navbar">
            
            <div class="brand-logo">
                <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
                <div class="brand-text">
                    <h1>MODERN SHOP8</h1>
                    <p>លម្អិតផលិតផល</p> 
                </div>
            </div>
            
            <div class="menu-toggle" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>

            <nav>
                <ul id="main-menu">
                    <li class="<?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>"><a href="index.php">ទំព័រដើម</a></li>
                    <li class="<?php echo ($current_page == 'cart.php') ? 'active-link' : ''; ?>"><a href="cart.php">រទេះទិញទំនិញ</a></li>
                    <li class="<?php echo ($current_page == 'history.php') ? 'active-link' : ''; ?>"><a href="history.php">ប្រវត្តិការទិញ</a></li>
                    <li class="<?php echo ($current_page == 'contact.php') ? 'active-link' : ''; ?>"><a href="contact.php">ទំនាក់ទំនង</a></li>
                    
                    <?php if ($is_admin): ?>
                        <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                        <li><a href="logout.php">ចាកចេញ</a></li>
                    <?php else: ?>
                        <li class="<?php echo ($current_page == 'admin_login.php') ? 'active-link' : ''; ?>"><a href="admin_login.php">ចូលជាអ្នកគ្រប់គ្រង</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <?php if ($product): ?>
            <div class="product-detail">
                <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                     onerror="this.src='https://via.placeholder.com/450x450?text=Product+Image+Unavailable'">
                
                <div class="product-info">
                    <h2><i class="fas fa-cube"></i> <?php echo htmlspecialchars($product['name']); ?></h2>
                    
                    <p class="price">
                        <i class="fas fa-tag"></i> តម្លៃ: $<?php echo htmlspecialchars(number_format($product['price'], 2)); ?>
                    </p>

                    <p class="description">
                        <i class="fas fa-info-circle"></i> **លម្អិត:**<br>
                        <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                    </p>
                    
                    <form method="POST" action="product.php?id=<?php echo htmlspecialchars($product['id']); ?>">
                        <input type="hidden" name="add_to_cart" value="1">
                        <div class="form-group">
                            <label for="quantity"><i class="fas fa-boxes"></i> ចំនួន:</label>
                            <input type="number" id="quantity" name="quantity" value="1" min="1" max="1000" required>
                        </div>
                        <button type="submit" class="btn">
                            <i class="fas fa-cart-plus"></i> បន្ថែមទៅក្នុងរទេះ
                        </button>
                    </form>
                </div>
            </div>
        <?php else: ?>
            <div class="error-message-box">
                <i class="fas fa-exclamation-triangle"></i>
                <p><?php echo htmlspecialchars($error_message); ?></p>
                <a href="index.php" class="btn" style="background-color: var(--button-primary); color: white; padding: 10px 20px; border-radius: 50px; text-decoration: none;">
                    ត្រលប់ទៅទំព័រដើម
                </a>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        function toggleMenu() {
            var menu = document.getElementById('main-menu');
            menu.classList.toggle('open');
        }
    </script>
    
</body>
</html>

<?php
// បិទការតភ្ជាប់បន្ទាប់ពីការដំណើរការ script ទាំងមូល
if (isset($conn)) {
    $conn->close();
}
?>
