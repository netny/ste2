<?php
// admin_product_form.php - ទំព័រសម្រាប់បន្ថែមឬកែប្រែផលិតផល
// រួមបញ្ចូលឯកសារ database.php ដែលមាន session_start() រួចហើយ
include 'database.php';

// ពិនិត្យមើលថាតើអ្នកប្រើប្រាស់បានចូលជាអ្នកគ្រប់គ្រងឬអត់
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: admin_login.php');
    exit;
}

$product = [
    'id' => null,
    'name' => '',
    'description' => '',
    'price' => '',
    'image_url' => ''
];
$page_title = "បន្ថែមផលិតផលថ្មី";
$error_message = '';
$success_message = '';

// គ្រប់គ្រងការដាក់ស្នើទម្រង់ (Form submission)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image_url = $_POST['image_url'];

    if ($id) {
        // កែប្រែផលិតផលដែលមានស្រាប់
        $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, price = ?, image_url = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ssdsi", $name, $description, $price, $image_url, $id);
            if ($stmt->execute()) {
                $success_message = "កែប្រែផលិតផលដោយជោគជ័យ!";
            } else {
                $error_message = "មានបញ្ហាក្នុងការកែប្រែផលិតផល។";
            }
            $stmt->close();
        }
    } else {
        // បន្ថែមផលិតផលថ្មី
        $stmt = $conn->prepare("INSERT INTO products (name, description, price, image_url) VALUES (?, ?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("ssds", $name, $description, $price, $image_url);
            if ($stmt->execute()) {
                $success_message = "បន្ថែមផលិតផលថ្មីដោយជោគជ័យ!";
                // បន្ទាប់ពីបន្ថែម សូមលាងសម្អាតទម្រង់
                $product = [
                    'id' => null,
                    'name' => '',
                    'description' => '',
                    'price' => '',
                    'image_url' => ''
                ];
            } else {
                $error_message = "មានបញ្ហាក្នុងការបន្ថែមផលិតផល។";
            }
            $stmt->close();
        }
    }
}

// ពិនិត្យមើលថាយើងកំពុងកែប្រែផលិតផលដែលមានស្រាប់ឬអត់ (សម្រាប់ GET request)
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $product = $result->fetch_assoc();
            $page_title = "កែប្រែផលិតផល: " . htmlspecialchars($product['name']);
        } else {
            $error_message = "រកមិនឃើញផលិតផលទេ។";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .img-preview {
            max-width: 200px;
            height: auto;
            margin-top: 10px;
            display: block;
            border: 1px solid #ccc;
            padding: 5px;
            border-radius: var(--border-radius);
        }
        .message-success {
            color: var(--add-button-bg);
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>MODERN SHOP8</h1>
            <nav>
                <ul>
                    <li><a href="index.php">ទំព័រដើម</a></li>
                    <li><a href="cart.php">រទេះទិញទំនិញ</a></li>
                    <li><a href="history.php">ប្រវត្តិការទិញ</a></li>
                    <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                        <li><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                        <li><a href="logout.php">ចាកចេញ</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container" style="max-width: 600px; margin-top: 50px; background-color: var(--card-background); padding: 30px; border-radius: var(--border-radius); box-shadow: var(--shadow);">
        <h2><?php echo htmlspecialchars($page_title); ?></h2>
        <?php if ($error_message): ?>
            <p style="color: var(--delete-button-bg); text-align: center;"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <p class="message-success"><?php echo htmlspecialchars($success_message); ?></p>
        <?php endif; ?>
        <form method="POST" action="admin_product_form.php">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($product['id']); ?>">
            <div class="form-group">
                <label for="name">ឈ្មោះផលិតផល:</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
            </div>
            <div class="form-group">
                <label for="description">បរិយាយ:</label>
                <textarea id="description" name="description" rows="5" required><?php echo htmlspecialchars($product['description']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="price">តម្លៃ:</label>
                <input type="number" id="price" name="price" step="0.01" value="<?php echo htmlspecialchars($product['price']); ?>" required>
            </div>
            <div class="form-group">
                <label for="image_url">តំណភ្ជាប់រូបភាព (URL):</label>
                <input type="text" id="image_url" name="image_url" value="<?php echo htmlspecialchars($product['image_url']); ?>" required>
                <?php if ($product['image_url']): ?>
                    <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="Current Image" class="img-preview">
                <?php endif; ?>
            </div>
            <button type="submit" class="btn" style="width: 100%;">រក្សាទុកផលិតផល</button>
        </form>
    </div>
</body>
</html>
<?php
// បិទការតភ្ជាប់បន្ទាប់ពីការដំណើរការ script ទាំងមូល
$conn->close();
?>
