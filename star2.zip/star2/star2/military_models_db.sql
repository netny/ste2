-- military_models_db.sql - ឯកសារសម្រាប់បង្កើត database និង tables
-- This SQL script creates the necessary database and tables for the e-commerce website.
-- To use this, you'll need a MySQL or MariaDB server.

-- Create the database
CREATE DATABASE IF NOT EXISTS `military_models_db`;
USE `military_models_db`;

-- Table for products
CREATE TABLE IF NOT EXISTS `products` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `description` TEXT NOT NULL,
    `price` DECIMAL(10, 2) NOT NULL,
    `image_url` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for users (admins)
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    -- 🚨 សំគាល់: សម្រាប់សុវត្ថិភាព គួរប្រើ PASSWORD_HASH() ក្នុងការបញ្ចូលពាក្យសម្ងាត់
    `password` VARCHAR(255) NOT NULL, 
    `is_admin` BOOLEAN NOT NULL DEFAULT FALSE,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for orders
CREATE TABLE IF NOT EXISTS `orders` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `total_price` DECIMAL(10, 2) NOT NULL,
    `purchase_date` DATETIME NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for order items
CREATE TABLE IF NOT EXISTS `order_items` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `order_id` INT(11) NOT NULL,
    `product_name` VARCHAR(255) NOT NULL,
    `quantity` INT(11) NOT NULL,
    `price` DECIMAL(10, 2) NOT NULL,
    PRIMARY KEY (`id`),
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for contacts
CREATE TABLE IF NOT EXISTS `contacts` (
    `id` INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `submission_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table for QR payment settings (តារាងដែលអ្នកត្រូវការ)
CREATE TABLE IF NOT EXISTS `qr_settings` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `bank_name` VARCHAR(50) NOT NULL UNIQUE,
    `account_name` VARCHAR(100) NOT NULL,
    `account_number` VARCHAR(50) NOT NULL,
    `qr_image_url` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- *******************************************
-- ✨ SAMPLE DATA INSERTS ✨
-- *******************************************

-- Initial QR settings data (Safe for re-runs using ON DUPLICATE KEY UPDATE)
INSERT INTO `qr_settings` (`bank_name`, `account_name`, `account_number`, `qr_image_url`) VALUES
('ABA Bank', 'MODERN SHOP8 CO., LTD', '001 123 456', 'https://placehold.co/250x250/004D66/ffffff?text=ABA+QR'),
('Acleda Bank', 'MODERN SHOP8 CO., LTD', '002 789 012', 'https://placehold.co/250x250/00A8A8/ffffff?text=Acleda+QR'),
('Wing Money', 'MODERN SHOP8 CO., LTD', '003 345 678', 'https://placehold.co/250x250/D9534F/ffffff?text=Wing+QR')
ON DUPLICATE KEY UPDATE 
    account_name=VALUES(account_name), 
    account_number=VALUES(account_number),
    qr_image_url=VALUES(qr_image_url);

-- Insert a default admin user (Using INSERT IGNORE to prevent error on re-run)
INSERT IGNORE INTO `users` (`username`, `password`, `is_admin`) VALUES
('admin', 'admin123', TRUE);

-- Insert sample products
INSERT INTO `products` (`name`, `description`, `price`, `image_url`) VALUES
('F-16 Fighter Jet Model', 'A detailed scale model of the F-16 Fighting Falcon. This model is perfect for collectors and enthusiasts, featuring realistic decals and a display stand.', '55.99', 'https://placehold.co/600x400/3498db/ffffff?text=F-16+Fighter+Jet'),
('T-90 Tank Model', 'A 1/35 scale model of the Russian T-90 main battle tank, featuring realistic paint and movable turret.', '49.99', 'https://placehold.co/600x400/909090/ffffff?text=T-90+Tank'),
('K2 Black Panther Tank Model', 'A high-quality replica of the K2 Black Panther tank, known for its advanced technology. This model is depicted in a snowy environment, ideal for winter dioramas.', '64.99', 'https://placehold.co/600x400/e0e0e0/000000?text=K2+Black+Panther'),
('Leopard 2A7V Tank Model', 'A finely crafted model of the German Leopard 2A7V tank. It comes with intricate details, a modern camouflage pattern, and a detailed interior view.', '69.99', 'https://placehold.co/600x400/7a8e7a/ffffff?text=Leopard+2A7V+Tank'),
('Dassault Rafale Fighter Jet', 'A scale model of the Dassault Rafale fighter jet. This kit includes decals for various air forces and detailed cockpit parts, offering a rewarding building experience.', '75.50', 'https://placehold.co/600x400/5c5c5c/ffffff?text=Rafale+Fighter+Jet'),
('Sukhoi Su-57 Fighter Jet', 'A futuristic model of the Russian Sukhoi Su-57 stealth fighter jet. It features a unique pixelated camouflage scheme and movable flight surfaces.', '89.00', 'https://placehold.co/600x400/364a66/ffffff?text=Su-57+Fighter+Jet');