<?php
// qr_payment.php - ទំព័រទូទាត់ជាមួយ QR Code/ផ្ទេរតាមធនាគារ (FUN STYLE)

// ចាប់ផ្តើមវគ្គ (Session)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ត្រូវប្រាកដថាអ្នកប្រើប្រាស់មានផលិតផលក្នុងរទេះ
if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

// =========================================================
// --- CORE DATA SETUP ---
// =========================================================
$current_page = basename(__FILE__);
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];

// Mock Cart Total (Calculate current total price)
$total_price = 0;
foreach ($_SESSION['cart'] as $item) {
    $total_price += ($item['price'] ?? 0) * ($item['quantity'] ?? 0);
}

// Generate a unique, fun Transaction ID (The "Cat ID")
if (!isset($_SESSION['cat_transaction_id'])) {
    $cat_id = 'CAT' . str_pad(mt_rand(10000, 99999), 5, '0', STR_PAD_LEFT);
    $_SESSION['cat_transaction_id'] = $cat_id;
} else {
    $cat_id = $_SESSION['cat_transaction_id'];
}

// Mock Bank Details (Replace with database query in a real app)
$bank_name = "Golden Paw Bank";
$account_name = "Mr. Meowser";
$account_number = "9988-7766-5544";

// Image URL Placeholder for QR Code
$qr_image_url = "https://placehold.co/300x300/006d77/ffd166?text=" . urlencode("SCAN ME: $cat_id");
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Code បង់ប្រាក់</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --success-color: #28a745;
            --card-background: #ffffff;
            --border-radius: 12px;
            --shadow-heavy: 0 10px 30px rgba(0, 0, 0, 0.15);
            --text-color: #333;
        }
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif;
            background-color: #f4f6f9;
            color: var(--text-color);
            padding-top: 20px;
        }
        .container {
            width: 90%; max-width: 600px; margin: 0 auto;
        }
        
        /* ======================================= */
        /* --- FUN STYLE QR PAYMENT BOX --- */
        /* ======================================= */
        .payment-box {
            background: var(--card-background); 
            padding: 40px; border-radius: 15px; 
            box-shadow: var(--shadow-heavy); 
            text-align: center; border: 3px dashed var(--secondary-color);
        }
        .payment-box h2 {
            color: var(--primary-color); 
            font-size: 2em; margin-bottom: 5px; border-bottom: 3px solid var(--secondary-color); padding-bottom: 10px;
        }
        .payment-info {
            font-size: 1.1em; margin-bottom: 25px; color: var(--text-color);
        }
        .qr-area img {
            width: 100%; max-width: 300px; height: auto; margin-bottom: 25px; 
            border: 5px solid var(--primary-color); border-radius: 15px; padding: 10px; background-color: #eee;
            animation: pulse 2s infinite; /* Fun animation */
        }
        .total-display {
            padding: 15px 30px; background-color: #e6ffed; color: var(--success-color);
            border-radius: 50px; margin: 20px auto 30px; display: inline-block;
            font-size: 1.6em; font-weight: 700; border: 2px solid var(--success-color);
        }
        .ref-id {
            padding: 10px 20px; background-color: var(--secondary-color); color: var(--primary-color);
            border-radius: 10px; font-size: 1.2em; font-weight: bold; margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1); 
        }
        .ref-id strong { font-size: 1.5em; }
        .bank-details p { margin: 8px 0; font-size: 1em; }
        .bank-details strong { color: var(--primary-color); display: inline-block; min-width: 120px; }
        
        /* Action Buttons */
        .action-buttons {
            display: flex; justify-content: center; gap: 15px; margin-top: 30px;
        }
        .btn-action {
            background-color: var(--primary-color); color: white; padding: 12px 25px; border-radius: 50px; 
            text-decoration: none; font-weight: bold; display: inline-flex; align-items: center; gap: 8px;
            transition: all 0.3s ease; box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        .btn-action:hover {
             transform: translateY(-2px); background-color: #004d53; 
        }
        .btn-invoice {
             background-color: var(--success-color) !important;
        }
        .btn-invoice:hover {
             background-color: #1e7e34 !important;
        }

        /* Animations */
        @keyframes pulse {
            0% { box-shadow: 0 0 0 0 rgba(0, 109, 119, 0.4); }
            70% { box-shadow: 0 0 0 15px rgba(0, 109, 119, 0); }
            100% { box-shadow: 0 0 0 0 rgba(0, 109, 119, 0); }
        }

        /* Responsive adjustments */
        @media (max-width: 480px) {
            .payment-box { padding: 20px; }
            .total-display { font-size: 1.4em; padding: 12px 20px; }
            .action-buttons { flex-direction: column; gap: 10px; }
            .btn-action { width: 100%; justify-content: center; }
            .qr-area img { max-width: 250px; }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="payment-box">
        <h2><i class="fas fa-qrcode"></i> ទូទាត់ប្រាក់ភ្លាមៗ</h2>
       
        <div class="total-display">
            តម្លៃដែលត្រូវបង់: $<?php echo htmlspecialchars(number_format($total_price, 2)); ?>
        </div>

      

        <div class="ref-id">
            លេខសម្គាល់ប្រតិបត្តិការ (Cat ID): <br><strong><?php echo htmlspecialchars($cat_id); ?></strong>
        </div>
        
        <p style="font-size: 0.9em; color: var(--primary-color);">
            <i class="fas fa-paw"></i> សូមប្រើ **Cat ID** នេះក្នុងកំណត់ចំណាំនៃការផ្ទេរ!
        </p>
        
        <p style="margin-top: 25px; font-weight: bold; color: var(--primary-color);">ព័ត៌មានលម្អិតគណនី:</p>

        <div class="bank-details">
            <p><i class="fas fa-university"></i> <strong>ធនាគារ:</strong> <?php echo htmlspecialchars($bank_name); ?></p>
            <p><i class="fas fa-user-circle"></i> <strong>ឈ្មោះ:</strong> <?php echo htmlspecialchars($account_name); ?></p>
            <p><i class="fas fa-hashtag"></i> <strong>លេខគណនី:</strong> <?php echo htmlspecialchars($account_number); ?></p>
        </div>

        <div class="action-buttons">
            <a href="cart.php" class="btn-action">
                <i class="fas fa-arrow-left"></i> ត្រលប់ទៅរទេះ
            </a>
            <a href="https://t.me/net112121212" class="btn-action btn-invoice">
                <i class="fas fa-file-invoice-dollar"></i> ទំនាក់ទំនងមកយើង
            <!-- Button to proceed to the DB commit/confirmation page 
        </div>
    </div>
</div>

</body>
</html>
