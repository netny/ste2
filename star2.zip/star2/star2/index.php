<?php
// index.php - ទំព័រចុះបញ្ជីផលិតផលសំខាន់ (កំណែមួយឯកសារពេញលេញ)

// រួមបញ្ចូលការតភ្ជាប់មូលដ្ឋានទិន្នន័យ (database.php នឹងចាប់ផ្តើម session និង $conn)
include 'database.php';

// ហៅយកផលិតផលទាំងអស់ពីមូលដ្ឋានទិន្នន័យ
$sql = "SELECT * FROM products ORDER BY id DESC";
$result = $conn->query($sql);

$products = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}

// Define current page for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']); 

// Check admin status for menu.php (if needed)
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MODERN SHOP8 - ផលិតផល</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --card-background: #ffffff;
            --border-radius: 8px;
            --shadow-light: 0 4px 6px rgba(0,0,0,0.1);
            --shadow-heavy: 0 8px 15px rgba(0,0,0,0.2);
            --text-color: #333;
            --light-text-color: #666;
        }
        
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif; /* Adjusted font stack */
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: var(--text-color);
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* ======================================= */
        /* --- HEADER & NAVIGATION STYLES --- */
        /* ======================================= */
        header {
            background-color: var(--primary-color);
            padding: 15px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        header .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 90%;
            max-width: 1200px;
            margin: auto;
            flex-wrap: wrap; 
        }

        /* --- LOGO STYLES (NEW/MODIFIED) --- */
        .brand-logo {
            display: flex; /* Use flex to align image and text */
            align-items: center; /* Vertically align */
            gap: 10px; /* Space between logo image and text */
            order: 1;
        }

        .brand-logo img {
            height: 40px; /* Adjust as needed for your logo image */
            width: auto;
            border-radius: 5px; /* Slightly rounded corners for the logo image */
            /* FIX: Ensure image background matches header background */
            background-color: var(--primary-color); 
            padding: 2px; /* Small padding if needed for a contained look */
        }

        .brand-text {
            display: flex;
            flex-direction: column;
            color: #fff;
            line-height: 1.2;
        }

        .brand-text h1 {
            font-size: 1.5em; /* Main logo text size */
            margin: 0;
            font-weight: bold;
        }

        .brand-text p {
            font-size: 0.8em; /* Tagline text size */
            margin: 0;
            opacity: 0.8;
        }
        /* --- END LOGO STYLES --- */


        header .navbar ul {
            list-style: none;
            display: flex; 
            gap: 20px;
            margin: 0;
            padding: 0;
            order: 3;
            width: 100%; /* Default for desktop */
            justify-content: flex-end;
        }
        header .navbar ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: 500;
            padding-bottom: 5px;
            transition: color 0.3s, border-bottom 0.3s;
        }
        header .navbar ul li a:hover,
        header .navbar ul li.active-link a {
            color: var(--secondary-color);
            border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle {
            display: none;
            cursor: pointer;
            font-size: 24px;
            color: #fff;
            order: 2;
        }

        /* ======================================= */
        /* --- COVER SECTION & TITLE --- */
        /* ======================================= */
        .cover-section {
            width: 100%;
            height: 360px;
            background-image: url('https://i.pinimg.com/736x/81/38/fb/8138fb53e8a404c43f53b79aecfd1915.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
            position: relative;
        }
        .cover-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.3);
            z-index: 1;
        }
        .cover-section h1 {
            font-size: 3em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            position: relative;
            z-index: 2;
            margin: 0;
        }
        .container h2 {
            text-align: center;
            font-size: 2.2em;
            color: var(--primary-color);
            margin-top: 25px;
            margin-bottom: 30px;
            border-bottom: 3px solid var(--secondary-color);
            padding-bottom: 10px;
        }

        /* ======================================= */
        /* --- CHAT BOT & FLOATING ICON --- */
        /* ======================================= */
        .floating-message {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5em;
            cursor: pointer;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            transition: all 0.3s ease;
            z-index: 1000;
            animation: pulse 2s infinite;
        }
        .floating-message::after {
            content: '';
            position: absolute;
            top: -5px;
            right: -5px;
            width: 20px;
            height: 20px;
            background-color: #ff4757;
            border-radius: 50%;
            border: 2px solid white;
            animation: ping 1.5s infinite;
        }
        .chat-box {
            position: fixed;
            bottom: 100px;
            right: 30px;
            width: 350px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            z-index: 1001;
            display: none;
            overflow: hidden;
            border: 2px solid var(--primary-color);
        }
        .chat-box.active {
            display: block;
        }
        .chat-header {
            padding: 15px 20px;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .chat-header h3 {
            margin: 0;
            font-size: 1.1em;
        }
        .chat-header .close-chat {
            background: none;
            border: none;
            color: white;
            font-size: 1.2em;
            cursor: pointer;
        }
        .chat-body {
            padding: 15px;
            max-height: 300px;
            overflow-y: auto;
            background: #fcfcfc;
        }
        .chat-message { margin-bottom: 15px; padding: 10px 15px; border-radius: 10px; font-size: 0.9em; line-height: 1.4; }
        .bot-message { background: #f1f3f4; color: #333; margin-right: 40px; }
        .user-message { background: var(--primary-color); color: white; margin-left: 40px; text-align: right; }
        .chat-input { padding: 15px 20px; border-top: 1px solid #eee; display: flex; gap: 10px; }
        .chat-input input { flex: 1; padding: 10px 15px; border: 1px solid #ddd; border-radius: 25px; outline: none; }
        .send-btn { background: var(--primary-color); color: white; border: none; border-radius: 50%; width: 40px; height: 40px; cursor: pointer; }

        /* Keyframes for animation */
        @keyframes pulse { 0% { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3); } 50% { box-shadow: 0 4px 25px rgba(52, 152, 219, 0.5); } 100% { box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3); } }
        @keyframes ping { 0% { transform: scale(1); opacity: 1; } 75%, 100% { transform: scale(2); opacity: 0; } }

        /* ======================================= */
        /* --- GRID SECTIONS (Features, Stats, Products) --- */
        /* ======================================= */
        .features-section { background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 10px 0; margin: 2px 0; }
        .features-grid, .quick-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            padding: 20px 0;
            margin: 0 auto;
            max-width: 1200px;
        }
        .stat-item, .feature-item { text-align: center; padding: 20px; background: var(--card-background); border-radius: var(--border-radius); box-shadow: var(--shadow-light); }
        .feature-item { background: transparent; box-shadow: none; padding: 10px; }
        .feature-icon { font-size: 3em; margin-bottom: 20px; color: white; }
        .product-item { background: var(--card-background); border-radius: var(--border-radius); padding: 20px; text-align: center; box-shadow: var(--shadow-light); transition: transform 0.3s ease; }
        .product-item img { width: 100%; height: 200px; object-fit: cover; border-radius: var(--border-radius); margin-bottom: 15px; }
        .product-item h3 { color: var(--primary-color); margin: 10px 0; font-size: 1.3em; min-height: 3em; display: flex; align-items: center; justify-content: center; }
        .product-item .price { color: var(--secondary-color); font-size: 1.4em; font-weight: bold; margin: 10px 0; }
        .product-item .btn { background-color: var(--primary-color); color: white; padding: 12px 24px; text-decoration: none; border-radius: var(--border-radius); display: inline-flex; align-items: center; gap: 8px; }


        /* ======================================= */
        /* --- FOOTER --- */
        /* ======================================= */
        footer {
            background-color: var(--primary-color);
            color: white;
            text-align: center;
            padding: 30px 0;
            margin-top: 50px;
        }
        .footer-content { max-width: 1200px; margin: 0 auto; padding: 0 20px; }
        .social-icons { margin: 20px 0; }
        .social-icons a { color: white; font-size: 1.5em; margin: 0 10px; transition: color 0.3s ease; }
        .social-icons a:hover { color: var(--secondary-color); }


        /* ======================================= */
        /* --- RESPONSIVE MEDIA QUERIES --- */
        /* ======================================= */
        
        @media (max-width: 992px) {
             /* Adjust menu stacking slightly earlier for mid-size tablets */
            header .navbar ul {
                justify-content: center;
                gap: 15px;
            }
        }
        
        @media (max-width: 768px) {
            /* Menu Stacking for Tablets/Mobile */
            .menu-toggle {
                display: block;
            }
            header .navbar {
                justify-content: space-between;
                align-items: center;
            }
             header .navbar ul {
                display: none; /* Hidden by default */
                flex-direction: column;
                justify-content: flex-start;
                background-color: #005660;
                padding: 10px 0;
                text-align: center;
                order: 4; 
            }
            header .navbar ul.open { /* Class added by JS toggle */
                display: flex; 
            }
            header .navbar ul li {
                width: 100%;
                border-top: 1px solid rgba(255, 255, 255, 0.1);
            }
            header .navbar ul li:first-child { border-top: none; }
            header .navbar ul li a { display: block; padding: 10px 0; }
            
            /* General Layout Adjustments */
            .cover-section { height: 250px; }
            .cover-section h1 { font-size: 2em; }
            .container h2 { font-size: 1.8em; }
            
            /* Grids stack to two columns for slightly larger tablets */
            .quick-stats { grid-template-columns: repeat(2, 1fr); }
            
            /* Footer text stacks better */
             .footer-content p { margin: 5px 0; }

            /* Logo adjustment on smaller screens */
            .brand-logo {
                flex-direction: column; /* Stack logo and tagline */
                align-items: flex-start; /* Align text to the left */
                gap: 2px;
            }
            .brand-logo h1 {
                font-size: 1.3em;
            }
            .brand-logo p {
                font-size: 0.7em;
            }
            .brand-logo img {
                height: 30px; /* Even smaller logo image */
            }
        }

        @media (max-width: 480px) {
            /* Mobile Phone Stacking */
            .cover-section { height: 200px; }
            .cover-section h1 { font-size: 1.5em; }

            /* All grids stack to single column */
            .product-grid, .features-grid, .quick-stats {
                grid-template-columns: 1fr;
                gap: 15px;
                padding: 10px;
            }
            .product-item img { height: 150px; }

            /* Chat Box - Mobile View */
            .floating-message { bottom: 15px; right: 15px; width: 50px; height: 50px; }
            .chat-box {
                width: calc(100% - 20px); 
                right: 10px;
                left: 10px;
                bottom: 80px;
                margin: 0 auto;
            }
            .chat-body { max-height: 250px; }

            /* Logo adjustment for very small screens */
            .brand-logo h1 {
                font-size: 1.2em;
            }
            .brand-logo p {
                font-size: 0.6em;
            }
            .brand-logo img {
                height: 30px; /* Even smaller logo image */
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            
            <div class="brand-logo">
                <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
                <div class="brand-text">
                    <h1>MODERN SHOP8</h1>
                    <p>ហាងលក់ទំនិញទំនើបសម្រាប់អ្នក!</p> 
                </div>
            </div>
            
            <div class="menu-toggle" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>

            <nav>
                <ul id="main-menu">
                    <li class="<?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>"><a href="index.php">ទំព័រដើម</a></li>
                    <li class="<?php echo ($current_page == 'cart.php') ? 'active-link' : ''; ?>"><a href="cart.php">រទេះទិញទំនិញ</a></li>
                    <li class="<?php echo ($current_page == 'history.php') ? 'active-link' : ''; ?>"><a href="history.php">ប្រវត្តិការទិញ</a></li>
                    <li class="<?php echo ($current_page == 'contact.php') ? 'active-link' : ''; ?>"><a href="contact.php">ទំនាក់ទំនង</a></li>
                    
                    <?php if ($is_admin): ?>
                        <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                        <li><a href="logout.php">ចាកចេញ</a></li>
                    <?php else: ?>
                        <li class="<?php echo ($current_page == 'admin_login.php') ? 'active-link' : ''; ?>"><a href="admin_login.php">ចូលជាអ្នកគ្រប់គ្រង</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="floating-message" onclick="toggleChat()">
        <i class="fas fa-comments"></i>
    </div>

    <div class="chat-box" id="chatBox">
        <div class="chat-header">
            <h3><i class="fas fa-headset"></i> សេវាកម្មអតិថិជន</h3>
            <button class="close-chat" onclick="toggleChat()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="chat-body" id="chatBody">
            <div class="chat-message bot-message">
                <strong>MODERN SHOP8:</strong> សួស្តី! តើយើងអាចជួយអ្នកបានយ៉ាងដូចម្តេច? 😊
            </div>
            <div class="chat-message bot-message">
                សូមសួរអំពីផលិតផល តម្លៃ ឬការដឹកជញ្ជូន។
            </div>
        </div>
        <div class="chat-input">
            <input type="text" id="chatInput" placeholder="វាយសាររបស់អ្នកនៅទីនេះ..." onkeypress="handleKeyPress(event)">
            <button class="send-btn" onclick="sendMessage()">
                <i class="fas fa-paper-plane"></i>
            </button>
        </div>
    </div>
    
    <div class="cover-section">
        <h1>WELCOME TO MODERN SHOP8</h1>
    </div>

    <div class="features-section">
        <div class="features-grid">
            <div class="feature-item">
                <div class="feature-icon"> <i class="fas fa-shipping-fast"></i> </div>
                <h3>ការដឹកជញ្ជូនរហ័ស</h3>
                <p>ដឹកជញ្ជូនរហ័សទៅកាន់ទីតាំងរបស់អ្នក</p>
            </div>
            <div class="feature-item">
                <div class="feature-icon"> <i class="fas fa-shield-alt"></i> </div>
                <h3>សុវត្ថិភាព</h3>
                <p>ការទូទាត់ដែលមានសុវត្ថិភាព និងអាចទុកចិត្តបាន</p>
            </div>
            <div class="feature-item">
                <div class="feature-icon"> <i class="fas fa-headset"></i> </div>
                <h3>គាំទ្រ 24/7</h3>
                <p>សេវាកម្មអតិថិជន 24 ម៉ោង</p>
            </div>
            <div class="feature-item">
                <div class="feature-icon"> <i class="fas fa-undo-alt"></i> </div>
                <h3>ត្រឡប់មកវិញ</h3>
                <p>និតិវិធីត្រឡប់ទំនិញយ៉ាងងាយស្រួល</p>
            </div>
        </div>
    </div>

    <div class="container">
        <h2><i class="fas fa-box-open"></i> ផលិតផលរបស់យើង</h2>
        
        <div class="quick-stats">
            <div class="stat-item">
                <div class="stat-icon"> <i class="fas fa-boxes"></i> </div>
                <div class="stat-number"><?php echo count($products); ?></div>
                <div class="stat-label">ផលិតផលសរុប</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"> <i class="fas fa-users"></i> </div>
                <div class="stat-number">500+</div>
                <div class="stat-label">អតិថិជនពេញចិត្ត</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"> <i class="fas fa-shipping-fast"></i> </div>
                <div class="stat-number">1000+</div>
                <div class="stat-label">ការបញ្ជាទិញ</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"> <i class="fas fa-map-marker-alt"></i> </div>
                <div class="stat-number">5+</div>
                <div class="stat-label">ទីតាំងសាខា</div>
            </div>
        </div>
        
        <?php if (empty($products)): ?>
            <div style="text-align: center; padding: 50px 20px;">
                <i class="fas fa-exclamation-circle" style="font-size: 4em; color: var(--light-text-color); margin-bottom: 20px;"></i>
                <p style="font-size: 1.2em; color: var(--light-text-color); margin-bottom: 20px;">
                    មិនទាន់មានផលិតផលណាមួយត្រូវបានបញ្ចូលនៅឡើយទេ។
                </p>
                <p style="color: var(--text-color);">
                    <i class="fas fa-info-circle"></i> សូមទាក់ទងអ្នកគ្រប់គ្រង។
                </p>
            </div>
        <?php else: ?>
            <div class="product-grid">
                <?php foreach ($products as $product): ?>
                    <div class="product-item">
                        <?php if (!empty($product['image_url'])): ?>
                            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 onerror="this.src='https://via.placeholder.com/200x200?text=No+Image'">
                        <?php else: ?>
                            <img src="https://via.placeholder.com/200x200?text=No+Image" alt="No image available">
                        <?php endif; ?>
                        
                        <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                        
                        <div class="price">
                            <i class="fas fa-tag"></i> $<?php echo htmlspecialchars(number_format($product['price'], 2)); ?>
                        </div>
                        
                        <?php if (!empty($product['description'])): ?>
                            <div class="description">
                                <i class="fas fa-info-circle"></i>
                                <?php echo htmlspecialchars(mb_substr($product['description'], 0, 100, 'UTF-8')); ?>
                                <?php if (mb_strlen($product['description'], 'UTF-8') > 100): ?>...<?php endif; ?>
                            </div>
                        <?php endif; ?>
                        
                        <a href="product.php?id=<?php echo htmlspecialchars($product['id']); ?>" class="btn">
                            <i class="fas fa-eye"></i> មើលលម្អិត
                        </a>
                        
                        <div class="product-meta">
                            <div class="stock-status in-stock">
                                <i class="fas fa-check-circle"></i> មានក្នុងស្តុក
                            </div>
                            <div class="rating">
                                <i class="fas fa-star" style="color: #ffc107;"></i>
                                <span>4.5</span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <div class="footer-content">
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-telegram"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
            <p>&copy; <?php echo date("Y"); ?> MODERN SHOP8. រក្សាសិទ្ធិគ្រប់យ៉ាង។</p>
            <p>
                <i class="fas fa-phone"></i> +855 12 345 678 | 
                <i class="fas fa-envelope"></i> info@modernshop8.com |
                <i class="fas fa-map-marker-alt"></i> ភ្នំពេញ, កម្ពុជា
            </p>
        </div>
    </footer>

    <script>
        function toggleMenu() {
            const menu = document.getElementById('main-menu');
            menu.classList.toggle('open');
        }
        
        function toggleChat() {
            const chatBox = document.getElementById('chatBox');
            chatBox.classList.toggle('active');
        }

        function handleKeyPress(event) {
            if (event.key === 'Enter') {
                sendMessage();
            }
        }

        function sendMessage() {
            const input = document.getElementById('chatInput');
            const message = input.value.trim();
            
            if (message === '') return;

            const chatBody = document.getElementById('chatBody');
            const userMessage = document.createElement('div');
            userMessage.className = 'chat-message user-message';
            userMessage.innerHTML = `<strong>អ្នក:</strong> ${message}`;
            chatBody.appendChild(userMessage);

            input.value = '';
            chatBody.scrollTop = chatBody.scrollHeight;

            const lowerMessage = message.toLowerCase();
            
            // Fixed Bot Response Logic
            setTimeout(() => {
                const botMessage = document.createElement('div');
                botMessage.className = 'chat-message bot-message';
                let response = "សូមអភ័យទោស, ខ្ញុំមិនទាន់យល់សំណួរនោះទេ។ តើអ្នកអាចសួរបញ្ជាក់បន្ថែមបានទេ? 🙏";
                
                
                if (lowerMessage.includes('តម្លៃ') || lowerMessage.includes('ថ្លៃ') || lowerMessage.includes('$')) {
                    response = `
                        <strong>តម្លៃ/ការទូទាត់:</strong> តម្លៃផលិតផលត្រូវបានបង្ហាញនៅលើទំព័រផលិតផលនីមួយៗ។ 
                        សម្រាប់ការទូទាត់ យើងទទួលយក Cash on Delivery (COD) និងការផ្ទេរប្រាក់តាមធនាគារក្នុងស្រុក។ 
                        ការទូទាត់មានសុវត្ថិភាពខ្ពស់។
                    `;
                } else if (lowerMessage.includes('ដឹកជញ្ជូន') || lowerMessage.includes('សំបុត្រ') || lowerMessage.includes('ပို့')) {
                    response = `
                        <strong>ការដឹកជញ្ជូន:</strong> យើងផ្តល់សេវាដឹកជញ្ជូនលឿនទូទាំងប្រទេសកម្ពុជា។ 
                        តម្លៃដឹកជញ្ជូនត្រូវបានគណនាតាមតំបន់។ ជាទូទៅ ការដឹកជញ្ជូនចំណាយពេល **១-៣ ថ្ងៃ** ក្នុងភ្នំពេញ និង **៣-៥ ថ្ងៃ** តាមបណ្ដាខេត្ត។
                    `;
                } else if (lowerMessage.includes('ស្តុក') || lowerMessage.includes('មាន')) {
                    response = `
                        <strong>ស្ថានភាពស្តុក:</strong> ផលិតផលទាំងអស់ដែលបង្ហាញនៅលើទំព័ររបស់យើងគឺមានក្នុងស្តុក (In Stock)។ 
                        ប្រសិនបើទំនិញអស់ (Out of Stock) វានឹងបង្ហាញជូនដំណឹងនៅលើទំព័រផលិតផលនោះ។
                    `;
                } else if (lowerMessage.includes('ត្រឡប់') || lowerMessage.includes('ប្តូរ')) {
                    response = `
                        <strong>គោលការណ៍ត្រឡប់ទំនិញ:</strong> យើងទទួលយកការប្តូរ/ត្រឡប់ទំនិញក្នុងរយៈពេល **៧ ថ្ងៃ** បន្ទាប់ពីទទួលបាន។ 
                        ទំនិញត្រូវតែនៅថ្មី និងមានវេចខ្ចប់ដើម។ សូមមើល "លក្ខខណ្ឌ" សម្រាប់ព័ត៌មានលម្អិត។
                    `;
                } else if (lowerMessage.includes('គាំទ្រ') || lowerMessage.includes('ជំនួយ') || lowerMessage.includes('លេខទូរស័ព្ទ')) {
                    response = `
                        <strong>ក្រុមគាំទ្រ:</strong> យើងមានសេវាកម្មអតិថិជន 24/7។ 
                        អ្នកអាចទាក់ទងមកយើងតាមរយៈ: 
                        <br>📞 **+855 12 345 678**
                        <br>📧 **info@modernshop8.com**
                    `;
                } else if (lowerMessage.includes('សួស្តី') || lowerMessage.includes('ជំរាបសួរ') || lowerMessage.includes('hello')) {
                     response = "សួស្តី! ខ្ញុំជាជំនួយការឆាតបូតរបស់ MODERN SHOP8។ តើអ្នកចង់សួរអំពី **ផលិតផល**, **តម្លៃ**, ឬ **ការដឹកជញ្ជូន** ដែរឬទេ? 😊";
                }
                
                botMessage.innerHTML = `<strong>MODERN SHOP8:</strong> ${response}`;
                chatBody.appendChild(botMessage);
                chatBody.scrollTop = chatBody.scrollHeight;
            }, 1000);
        }

        // Close chat when clicking outside
        document.addEventListener('click', function(event) {
            const chatBox = document.getElementById('chatBox');
            const floatingMessage = document.querySelector('.floating-message');
            
            if (chatBox.classList.contains('active') && 
                !chatBox.contains(event.target) && 
                !floatingMessage.contains(event.target)) {
                chatBox.classList.remove('active');
            }
        });
    </script>
</body>
</html>

<?php
// បិទការតភ្ជាប់បន្ទាប់ពីការដំណើរការ script ទាំងមូល
if (isset($conn)) {
    $conn->close();
}
?>
