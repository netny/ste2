<?php
// logout.php - ឯកសារសម្រាប់ដំណើរការចេញពីគណនីរបស់អ្នកគ្រប់គ្រង
// ឯកសារនេះត្រូវគ្នាជាមួយកូដរបស់អ្នកទាំងអស់

// ចាប់ផ្ដើម session
session_start();

// លុប session variables ទាំងអស់ចោល
$_SESSION = array();

// បំផ្លាញ session
// នេះជាវិធីសាស្រ្តសុវត្ថិភាពដើម្បីបំផ្លាញ session ដោយលុប cookie ផងដែរ។
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

session_destroy();

// ប្ដូរទិសដៅអ្នកប្រើប្រាស់ទៅទំព័រដើម
header('Location: index.php');
exit;
?>
