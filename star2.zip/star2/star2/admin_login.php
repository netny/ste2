<?php
// admin_login.php - ទំព័រចូលសម្រាប់អ្នកគ្រប់គ្រង (FUN STYLE)
include 'database.php';

// ចាប់ផ្តើម session ប្រសិនបើវាមិនទាន់បានចាប់ផ្តើម
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current script name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']); 
// Check admin status for menu.php (if needed)
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];


$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        
        // --- NOTE: Plain text password storage is insecure. In a real app, hash checking is mandatory. ---
        
        // ពិនិត្យមើលក្នុង database សម្រាប់អ្នកប្រើប្រាស់ណាមួយ
        $stmt = $conn->prepare("SELECT id, username, is_admin FROM users WHERE username = ? AND password = ?");
        
        if ($stmt === false) {
            $error_message = 'មានបញ្ហាក្នុងការរៀបចំសំណួរ៖ ' . htmlspecialchars($conn->error);
        } else {
            $stmt->bind_param("ss", $username, $password);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();
            
            if ($user) {
                // កំណត់ session variable
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['is_admin'] = $user['is_admin'];

                // ពិនិត្យមើលថាតើជា admin ឬជា user ធម្មតា
                if ($user['is_admin']) {
                    header('Location: admin.php');
                } else {
                    header('Location: index.php');
                }
                exit;
            } else {
                $error_message = 'ឈ្មោះអ្នកប្រើប្រាស់ ឬពាក្យសម្ងាត់មិនត្រឹមត្រូវ។';
            }
        }
    }
}

// Prepare logout/login links based on session status
$nav_links = '';
if ($is_admin) {
    $nav_links .= '<li><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>';
    $nav_links .= '<li><a href="logout.php">ចាកចេញ</a></li>';
} elseif (isset($_SESSION['user_id'])) {
    $nav_links .= '<li><a href="logout.php">ចាកចេញ</a></li>';
} else {
    $nav_links .= '<li class="' . ($current_page == 'admin_login.php' ? 'active-link' : '') . '"><a href="admin_login.php">ចូលគណនី</a></li>';
    $nav_links .= '<li class="' . ($current_page == 'register.php' ? 'active-link' : '') . '"><a href="register.php">ចុះឈ្មោះ</a></li>';
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ចូលគណនីអ្នកគ្រប់គ្រង</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --card-background: #ffffff;
            --border-radius: 8px;
            --shadow: 0 4px 6px rgba(0,0,0,0.1);
            --shadow-heavy: 0 10px 30px rgba(0,0,0,0.15);
            --delete-button-bg: #e63946;
            --text-color: #333;
        }
        
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif;
            background-color: #f4f4f9;
            color: var(--text-color);
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* ======================================= */
        /* --- HEADER & NAVIGATION (FUN/RESPONSIVE) --- */
        /* ======================================= */
        header { background-color: var(--primary-color); padding: 15px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        header .navbar {
            display: flex; justify-content: space-between; align-items: center; width: 90%; max-width: 1200px; margin: auto; flex-wrap: wrap; 
        }
        .brand-logo { display: flex; align-items: center; gap: 10px; order: 1; }
        .brand-logo img { height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px; }
        .brand-text { display: flex; flex-direction: column; color: #fff; line-height: 1.2; }
        .brand-text h1 { font-size: 1.5em; margin: 0; font-weight: bold; }
        .brand-text p { font-size: 0.8em; margin: 0; opacity: 0.8; }
        header nav ul {
            list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; order: 3; width: 100%; justify-content: flex-end;
        }
        header nav ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header nav ul li a:hover,
        header nav ul li.active-link a {
            color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle { display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2; }
        
        /* Mobile Menu */
        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            header .navbar ul { display: none; flex-direction: column; order: 4; background-color: #005660; }
            header .navbar ul.open { display: flex; }
            .brand-logo { flex-direction: column; align-items: flex-start; gap: 2px; }
        }

        /* ======================================= */
        /* --- LOGIN FORM FUN STYLE --- */
        /* ======================================= */
        .login-container {
            max-width: 500px;
            margin: 50px auto;
            background-color: var(--card-background);
            padding: 40px;
            border-radius: 15px; /* Fun: Rounded corners */
            box-shadow: var(--shadow-heavy);
            border: 2px solid var(--secondary-color); /* Fun: Highlight border */
            animation: fadeIn 0.8s ease-out;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: var(--primary-color);
            font-size: 2em;
            border-bottom: 3px solid var(--secondary-color);
            padding-bottom: 10px;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: none; /* Hide label, use icon/placeholder */
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 12px 12px 40px; /* Space for icon */
            border: 2px solid #ddd;
            border-radius: 50px; /* Pill shape for inputs */
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        
        .form-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--light-text-color);
            transition: color 0.3s ease;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--secondary-color);
            box-shadow: 0 0 8px rgba(255, 209, 102, 0.5);
        }

        .form-group input:focus + i {
            color: var(--primary-color);
        }
        
        .btn-submit {
            width: 100%;
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 15px;
            font-size: 1.2em;
            cursor: pointer;
            border-radius: 50px;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .btn-submit:hover {
            background-color: var(--secondary-color);
            color: var(--primary-color);
            transform: translateY(-3px);
            box-shadow: 0 6px 10px rgba(0,0,0,0.2);
        }

        .error-message-box {
            background-color: #f8d7da;
            color: var(--delete-button-bg);
            padding: 15px;
            border-radius: 10px;
            border: 1px solid #f5c6cb;
            text-align: center;
            font-weight: bold;
            margin-bottom: 20px;
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @media (max-width: 500px) {
            .login-container {
                margin: 20px 10px;
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container navbar">
            <div class="brand-logo">
                <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
                <div class="brand-text">
                    <h1>MODERN SHOP8</h1>
                    <p>ចូលគណនី</p> 
                </div>
            </div>
            
            <div class="menu-toggle" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>

            <nav>
                <ul id="main-menu">
                    <li class="<?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>"><a href="index.php">ទំព័រដើម</a></li>
                    <li class="<?php echo ($current_page == 'cart.php') ? 'active-link' : ''; ?>"><a href="cart.php">រទេះទិញទំនិញ</a></li>
                    <li class="<?php echo ($current_page == 'history.php') ? 'active-link' : ''; ?>"><a href="history.php">ប្រវត្តិការទិញ</a></li>
                    <li class="<?php echo ($current_page == 'contact.php') ? 'active-link' : ''; ?>"><a href="contact.php">ទំនាក់ទំនង</a></li>
                    <?php echo $nav_links; ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container login-container">
        <h2><i class="fas fa-lock" style="color: var(--secondary-color);"></i> សូមចូលគណនី</h2>
        <?php if ($error_message): ?>
            <div class="error-message-box">
                <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="admin_login.php">
            <div class="form-group">
                <label for="username">ឈ្មោះអ្នកប្រើប្រាស់:</label>
                <input type="text" id="username" name="username" placeholder="ឈ្មោះអ្នកប្រើប្រាស់..." required>
                <i class="fas fa-user"></i>
            </div>
            <div class="form-group">
                <label for="password">ពាក្យសម្ងាត់:</label>
                <input type="password" id="password" name="password" placeholder="ពាក្យសម្ងាត់..." required>
                <i class="fas fa-key"></i>
            </div>
            <button type="submit" class="btn-submit">
                <i class="fas fa-sign-in-alt"></i> ចូល
            </button>
            <p style="text-align: center; margin-top: 20px;">
                មិនទាន់មានគណនី? <a href="register.php" style="color: var(--primary-color); font-weight: bold; text-decoration: none;">ចុះឈ្មោះនៅទីនេះ</a>
            </p>
        </form>
    </div>
    
    <script>
        function toggleMenu() {
            var menu = document.getElementById('main-menu');
            menu.classList.toggle('open');
        }
    </script>
</body>
</html>
<?php
// បិទការតភ្ជាប់បន្ទាប់ពីការដំណើរការ script ទាំងមូល
if (isset($conn)) {
    $conn->close();
}
?>