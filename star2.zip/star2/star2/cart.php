<?php
// cart.php - ទំព័ររទេះទិញទំនិញ (កំណែដែលបានកែររចនាបថ FUN STYLE)

// រួមបញ្ចូលការតភ្ជាប់មូលដ្ឋានទិន្នន័យ
include 'database.php';

// ចាប់ផ្តើម session ប្រសិនបើមិនទាន់ (ចាំបាច់សម្រាប់ cart)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current script name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']); 

// Check admin status for menu.php (if needed)
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];


// គ្រប់គ្រងការលុបផលិតផលចេញពីក្នុងរទេះ
if (isset($_GET['remove']) && is_numeric($_GET['remove'])) {
    $product_id_to_remove = intval($_GET['remove']);
    if (isset($_SESSION['cart'][$product_id_to_remove])) {
        unset($_SESSION['cart'][$product_id_to_remove]);
    }
    header('Location: cart.php');
    exit;
}

// គណនាតម្លៃសរុប
$total_price = 0;
// ពិនិត្យមើលថាតើរទេះទិញទំនិញត្រូវបានកំណត់ឬអត់
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $total_price += $item['price'] * $item['quantity'];
    }
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>រទេះទិញទំនិញ</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --card-background: #ffffff;
            --border-radius: 8px;
            --shadow-heavy: 0 10px 30px rgba(0,0,0,0.15);
            --text-color: #333;
            --light-text-color: #ddd; 
            --delete-color: #dc3545;
        }
        
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif; 
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: var(--text-color);
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* ======================================= */
        /* --- HEADER & NAVIGATION (FUN/RESPONSIVE) --- */
        /* ======================================= */
        header { background-color: var(--primary-color); padding: 15px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        header .navbar {
            display: flex; justify-content: space-between; align-items: center; width: 90%; max-width: 1200px; margin: auto; flex-wrap: wrap; 
        }
        .brand-logo { display: flex; align-items: center; gap: 10px; order: 1; }
        .brand-logo img { height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px; }
        .brand-text { display: flex; flex-direction: column; color: #fff; line-height: 1.2; }
        .brand-text h1 { font-size: 1.5em; margin: 0; font-weight: bold; }
        .brand-text p { font-size: 0.8em; margin: 0; opacity: 0.8; }
        header .navbar ul {
            list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; order: 3; width: 100%; justify-content: flex-end;
        }
        header .navbar ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header .navbar ul li a:hover,
        header .navbar ul li.active-link a {
            color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle { display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2; }
        
        /* Mobile Menu */
        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            header .navbar ul { display: none; flex-direction: column; order: 4; background-color: #005660; }
            header .navbar ul.open { display: flex; }
            .brand-logo { flex-direction: column; align-items: flex-start; gap: 2px; }
        }

        /* ======================================= */
        /* --- FUN STYLE CART SPECIFIC CSS --- */
        /* ======================================= */
        
        .cart-container {
            padding: 30px; border-radius: 15px; box-shadow: 0 10px 20px rgba(0,0,0,0.15); 
            max-width: 800px; margin: 50px auto; background-color: var(--card-background);
            border: 3px dashed var(--secondary-color);
        }
        
        .cart-container h2 {
            font-size: 2em; color: var(--primary-color); text-align: center; margin-bottom: 30px;
        }

        .cart-item {
            display: flex; justify-content: space-between; align-items: center; 
            border-bottom: 1px solid var(--light-text-color); padding: 15px; 
            background-color: #fff; margin: 10px 0; border-radius: var(--border-radius);
            transition: all 0.3s ease;
        }
        .cart-item:hover {
            box-shadow: 0 4px 10px rgba(0,0,0,0.1); transform: scale(1.01);
        }
        
        .cart-item-info h4 {
            margin: 0; color: var(--primary-color); font-size: 1.2em;
        }
        .cart-item-info p {
            margin: 5px 0 0 0; color: var(--text-color); font-size: 1em; font-weight: 500;
        }
        
        .cart-total {
            text-align: right; font-size: 1.8em; font-weight: 900; color: var(--delete-color); 
            margin-top: 20px; padding-top: 15px; border-top: 3px solid var(--secondary-color); 
        }
        
        .checkout-buttons {
            display: flex; justify-content: space-between; margin-top: 30px; gap: 15px;
        }
        .checkout-buttons .btn {
            flex: 1; text-align: center; padding: 15px 20px; text-decoration: none; 
            border-radius: 50px; font-weight: bold; display: inline-flex; align-items: center; 
            justify-content: center; gap: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        .btn-remove {
            background-color: var(--delete-color); color: white; border-radius: var(--border-radius);
            padding: 8px 15px; font-size: 0.9em; flex: none !important;
        }
        .btn-remove:hover { background-color: #c82333; transform: translateY(-2px); }
        .btn-qr-checkout {
            background-color: var(--secondary-color); color: var(--primary-color); font-weight: 900;
        }
        .btn-qr-checkout:hover {
            background-color: var(--primary-color); color: var(--secondary-color);
            transform: scale(1.05); box-shadow: 0 6px 10px rgba(0,0,0,0.2);
        }
        
        /* Mobile specific adjustments */
        @media (max-width: 768px) {
            .cart-item { flex-direction: column; align-items: flex-start; text-align: left; }
            .cart-item-info { width: 100%; margin-bottom: 10px; }
            .btn-remove { align-self: flex-end; } 
            .checkout-buttons { flex-direction: column; gap: 10px; }
            .checkout-buttons .btn { width: 100%; font-size: 1em; }
        }
    </style>
</head>
<body>
    <header>
        <div class="navbar">
            
            <div class="brand-logo">
                <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
                <div class="brand-text">
                    <h1>MODERN SHOP8</h1>
                    <p>ហាងលក់ទំនិញទំនើបសម្រាប់អ្នក!</p> 
                </div>
            </div>
            
            <div class="menu-toggle" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>

            <nav>
                <ul id="main-menu" class="<?php echo !empty($_GET['menu']) ? 'open' : ''; ?>">
                    <li class="<?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>"><a href="index.php">ទំព័រដើម</a></li>
                    <li class="<?php echo ($current_page == 'cart.php') ? 'active-link' : ''; ?>"><a href="cart.php">រទេះទិញទំនិញ</a></li>
                    <li class="<?php echo ($current_page == 'history.php') ? 'active-link' : ''; ?>"><a href="history.php">ប្រវត្តិការទិញ</a></li>
                    <li class="<?php echo ($current_page == 'contact.php') ? 'active-link' : ''; ?>"><a href="contact.php">ទំនាក់ទំនង</a></li>
                    
                    <?php if ($is_admin): ?>
                        <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                        <li><a href="logout.php">ចាកចេញ</a></li>
                    <?php else: ?>
                        <li class="<?php echo ($current_page == 'admin_login.php') ? 'active-link' : ''; ?>"><a href="admin_login.php">ចូលជាអ្នកគ្រប់គ្រង</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="main-content">
        <div class="cart-container">
            <h2 style="text-align: center; margin-bottom: 30px; color: var(--primary-color);">
                <i class="fas fa-shopping-cart" style="color: var(--secondary-color);"></i> 
                រទេះទិញទំនិញរបស់អ្នក
            </h2>
            
            <?php if (empty($_SESSION['cart'])): ?>
                <div class="empty-cart">
                    <p>រទេះទិញទំនិញរបស់អ្នកនៅទទេរ។</p>
                    <a href="index.php" class="btn" style="background-color: var(--primary-color); color: white;">
                        <i class="fas fa-store"></i> បន្តទិញទំនិញ
                    </a>
                </div>
            <?php else: ?>
                <div class="cart-items">
                    <?php foreach ($_SESSION['cart'] as $product_id => $item): ?>
                        <div class="cart-item">
                            <div class="cart-item-info">
                                <h4><?php echo htmlspecialchars($item['name']); ?></h4>
                                <p>
                                    <i class="fas fa-boxes"></i> ចំនួន: <?php echo htmlspecialchars($item['quantity']); ?> 
                                    - <i class="fas fa-dollar-sign"></i> តម្លៃសរុប: $<?php echo htmlspecialchars(number_format($item['price'] * $item['quantity'], 2)); ?>
                                </p>
                            </div>
                            <a href="cart.php?remove=<?php echo $product_id; ?>" class="btn btn-remove" onclick="return confirm('តើអ្នកពិតជាចង់លុបផលិតផលនេះចេញពីរទេះមែនទេ?')">
                                <i class="fas fa-trash-alt"></i> លុបចេញ
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="cart-total">
                    <i class="fas fa-money-check-alt"></i> តម្លៃសរុបដែលត្រូវបង់: $<?php echo htmlspecialchars(number_format($total_price, 2)); ?>
                </div>
                <div class="checkout-buttons">
                    <a href="index.php" class="btn" style="background-color: var(--primary-color); color: white;">
                        <i class="fas fa-shopping-bag"></i> បន្តទិញទំនិញ
                    </a>
                    <a href="checkout.php" class="btn btn-qr-checkout">
                        <i class="fas fa-credit-card"></i> បញ្ចប់ការទូទាត់ (Checkout)
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function toggleMenu() {
            const menu = document.getElementById('main-menu');
            menu.classList.toggle('open');
        }
    </script>
 
</body>
</html>
<?php
// បិទការតភ្ជាប់បន្ទាប់ពីការដំណើរការ script ទាំងមូល
if (isset($conn)) {
    $conn->close();
}
?>
