<?php
// database.php - ឯកសារសម្រាប់ភ្ជាប់ទៅមូលដ្ឋានទិន្នន័យ

// ចាប់ផ្តើម session ដើម្បីគ្រប់គ្រងរទេះទិញទំនិញ និងស្ថានភាពចូលរបស់អ្នកគ្រប់គ្រង
session_start();

// Database connection details
// សម្រាប់គម្រោងក្នុងផលិតកម្ម (production) គួរប្រើ .env ដើម្បីរក្សាទុកព័ត៌មាននេះ
$servername = "localhost";
$username = "root"; // ប្រើឈ្មោះអ្នកប្រើប្រាស់មូលដ្ឋានទិន្នន័យរបស់អ្នក
$password = "";     // ប្រើពាក្យសម្ងាត់មូលដ្ឋានទិន្នន័យរបស់អ្នក
$dbname = "military_models_db";

// បង្កើតការតភ្ជាប់
$conn = new mysqli($servername, $username, $password, $dbname);

// ពិនិត្យមើលការតភ្ជាប់
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// បង្កើតរទេះទិញទំនិញប្រសិនបើវាមិនទាន់មាន
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}
?>
