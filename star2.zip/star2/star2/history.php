<?php
// history.php - ទំព័រប្រវត្តិការទិញ (កំណែ FUN STYLE)

include 'database.php';

// ចាប់ផ្តើម session ប្រសិនបើមិនទាន់ (ចាំបាច់សម្រាប់ admin check)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ពិនិត្យថា អ្នកប្រើប្រាស់ជាអ្នកគ្រប់គ្រងឬអត់
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];

// Get the current script name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']); 

// លុបការបញ្ជាទិញ (Admin only)
if ($is_admin && isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $order_id_to_delete = intval($_GET['delete']);
    $conn->begin_transaction();

    try {
        $stmt_items = $conn->prepare("DELETE FROM order_items WHERE order_id = ?");
        $stmt_items->bind_param("i", $order_id_to_delete);
        $stmt_items->execute();
        $stmt_items->close();

        $stmt_order = $conn->prepare("DELETE FROM orders WHERE id = ?");
        $stmt_order->bind_param("i", $order_id_to_delete);
        $stmt_order->execute();
        $stmt_order->close();

        $conn->commit();
    } catch (mysqli_sql_exception $e) {
        $conn->rollback();
    }

    header('Location: history.php');
    exit;
}

// ហៅយកការបញ្ជាទិញទាំងអស់
$sql = "SELECT * FROM orders ORDER BY purchase_date DESC";
$result_orders = $conn->query($sql);
$orders = [];
if ($result_orders && $result_orders->num_rows > 0) {
    while ($row = $result_orders->fetch_assoc()) {
        $orders[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ប្រវត្តិការទិញ - MODERN SHOP8</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP (FROM INDEX.PHP) --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --card-background: #ffffff;
            --border-radius: 8px;
            --shadow-light: 0 4px 6px rgba(0,0,0,0.1);
            --shadow-heavy: 0 8px 15px rgba(0,0,0,0.2);
            --text-color: #333;
            --light-text-color: #666;
            --delete-color: #e63946;
        }

        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif; 
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: var(--text-color);
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* ======================================= */
        /* --- HEADER & NAVIGATION (FUN/RESPONSIVE) --- */
        /* ======================================= */
        header {
            background-color: var(--primary-color);
            padding: 15px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        header .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 90%;
            max-width: 1200px;
            margin: auto;
            flex-wrap: wrap; 
        }
        .brand-logo {
            display: flex; align-items: center; gap: 10px; order: 1;
        }
        .brand-logo img {
            height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px;
        }
        .brand-text {
            display: flex; flex-direction: column; color: #fff; line-height: 1.2;
        }
        .brand-text h1 {
            font-size: 1.5em; margin: 0; font-weight: bold;
        }
        .brand-text p {
            font-size: 0.8em; margin: 0; opacity: 0.8;
        }
        header .navbar ul {
            list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; order: 3; width: 100%; justify-content: flex-end;
        }
        header .navbar ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header .navbar ul li a:hover,
        header .navbar ul li.active-link a {
            color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle {
            display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2;
        }
        /* Mobile Specific Menu Styles */
        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            header .navbar ul { display: none; flex-direction: column; order: 4; }
            header .navbar ul.open { display: flex; background-color: #005660; }
            .brand-logo { flex-direction: column; align-items: flex-start; gap: 2px; }
        }

        /* ======================================= */
        /* --- HISTORY PAGE FUN STYLE --- */
        /* ======================================= */
        .history-container {
            background-color: var(--card-background);
            box-shadow: var(--shadow-heavy); /* Use heavy shadow for pop */
            padding: 30px;
            border-radius: 15px; /* More rounded corners */
            max-width: 900px;
            margin: 40px auto;
        }
        
        .history-container h2 {
            font-size: 2em;
            color: var(--primary-color);
            border-bottom: 3px solid var(--secondary-color);
            padding-bottom: 10px;
            margin-bottom: 30px;
            text-align: center;
        }

        .order-card {
            border: 2px solid #ddd;
            border-left: 8px solid var(--secondary-color); /* Highlight color on the side */
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
            background-color: #fcfcfc;
            box-shadow: var(--shadow-light);
            transition: all 0.3s ease;
        }
        .order-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }

        .order-card h3 {
            margin-top: 0;
            border-bottom: 2px dotted var(--primary-color);
            padding-bottom: 10px;
            font-size: 1.4em;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: var(--primary-color);
        }

        .order-card ul {
            list-style-type: none;
            padding: 0;
        }

        .order-card ul li {
            padding: 8px 0;
            border-bottom: 1px dotted #ccc;
            display: flex;
            justify-content: space-between;
            font-size: 1em;
        }

        .order-card ul li:last-child {
            border-bottom: none;
        }
        
        .order-total {
            font-weight: bold;
            text-align: right;
            font-size: 1.5em;
            margin-top: 15px;
            color: var(--delete-color); /* Use a strong color for the total */
            padding-top: 10px;
        }

        .btn-remove-small {
            padding: 5px 10px;
            font-size: 0.8em;
            background-color: var(--delete-color);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: 0.3s;
        }
        
        .btn-remove-small:hover {
            background-color: #d62828;
            transform: scale(1.05);
        }
        
        /* Mobile specific adjustments for cards */
        @media (max-width: 500px) {
            .order-card ul li {
                flex-direction: column;
                align-items: flex-start;
            }
            .order-card ul li span {
                font-size: 0.9em;
                margin-top: 5px;
                color: var(--light-text-color);
            }
        }
    </style>
</head>
<body>

<header>
    <div class="navbar">
        <div class="brand-logo">
            <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
            <div class="brand-text">
                <h1>MODERN SHOP8</h1>
                <p>ហាងលក់ទំនិញទំនើបសម្រាប់អ្នក!</p> 
            </div>
        </div>
        
        <div class="menu-toggle" onclick="toggleMenu()">
            <i class="fas fa-bars"></i>
        </div>

        <nav>
            <ul id="main-menu">
                <li class="<?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>"><a href="index.php">ទំព័រដើម</a></li>
                <li class="<?php echo ($current_page == 'cart.php') ? 'active-link' : ''; ?>"><a href="cart.php">រទេះទិញទំនិញ</a></li>
                <li class="<?php echo ($current_page == 'history.php') ? 'active-link' : ''; ?>"><a href="history.php">ប្រវត្តិការទិញ</a></li>
                <li class="<?php echo ($current_page == 'contact.php') ? 'active-link' : ''; ?>"><a href="contact.php">ទំនាក់ទំនង</a></li>
                
                <?php if ($is_admin): ?>
                    <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                    <li><a href="logout.php">ចាកចេញ</a></li>
                <?php else: ?>
                    <li class="<?php echo ($current_page == 'admin_login.php') ? 'active-link' : ''; ?>"><a href="admin_login.php">ចូលជាអ្នកគ្រប់គ្រង</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>

<div class="container history-container">
    <h2><i class="fas fa-archive" style="color: var(--secondary-color);"></i> ប្រវត្តិការទិញ</h2>
    <?php if (empty($orders)): ?>
        <p style="text-align: center; font-size: 1.2em; color: var(--light-text-color);">អ្នកមិនទាន់មានប្រវត្តិការទិញនៅឡើយទេ។</p>
    <?php else: ?>
        <?php foreach ($orders as $order): ?>
            <div class="order-card">
                <h3>
                    <i class="fas fa-receipt" style="color: var(--secondary-color);"></i> ការបញ្ជាទិញ #<?php echo htmlspecialchars($order['id']); ?>
                    <?php if ($is_admin): ?>
                        <a href="history.php?delete=<?php echo htmlspecialchars($order['id']); ?>" class="btn-remove-small" onclick="return confirm('តើអ្នកពិតជាចង់លុបការបញ្ជាទិញនេះមែនទេ?');">
                            <i class="fas fa-times-circle"></i> លុប
                        </a>
                    <?php endif; ?>
                </h3>
                <p style="font-size: 0.9em; color: var(--light-text-color);">
                    <i class="fas fa-calendar-alt"></i> កាលបរិច្ឆេទ: <?php echo htmlspecialchars(date('d-M-Y H:i', strtotime($order['purchase_date']))); ?>
                </p>
                
                <p style="margin-top: 15px;"><strong>ផលិតផលដែលបានទិញ:</strong></p>
                <ul>
                    <?php
                    $stmt_items = $conn->prepare("SELECT product_name, quantity, price FROM order_items WHERE order_id = ?");
                    $stmt_items->bind_param("i", $order['id']);
                    $stmt_items->execute();
                    $result_items = $stmt_items->get_result();

                    if ($result_items->num_rows > 0) {
                        while ($item = $result_items->fetch_assoc()) {
                            echo "<li>" . htmlspecialchars($item['product_name']) . 
                                 "<span> ចំនួន: " . htmlspecialchars($item['quantity']) . 
                                 " - តម្លៃឯកតា: $" . htmlspecialchars(number_format($item['price'], 2)) . "</span></li>";
                        }
                    }
                    $stmt_items->close();
                    ?>
                </ul>
                <div class="order-total">
                    <i class="fas fa-tags"></i> តម្លៃសរុប: $<?php echo htmlspecialchars(number_format($order['total_price'], 2)); ?>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<footer>
    <p>© 2025 MODERN SHOP8 - រក្សាសិទ្ធិគ្រប់យ៉ាង។</p>
</footer>

<script>
    function toggleMenu() {
        var menu = document.getElementById('main-menu');
        menu.classList.toggle('open');
    }
</script>

</body>
</html>

<?php
$conn->close();
?>