<?php
// invoice.php - ទំព័រសម្រាប់បង្ហាញវិក្កយបត្រ (Invoice)

// ចាប់ផ្តើម session ប្រសិនបើមិនទាន់
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// =========================================================
// --- CORE DATA RETRIEVAL (Mocking based on ref ID) ---
// =========================================================
$reference_id = $_GET['ref'] ?? 'N/A';

// --- MOCK INVOICE DATA ---
$invoice_id = 'INV-' . substr($reference_id, 3);
$invoice_date = date('Y-m-d H:i:s'); 

// Mocking the data that would normally come from the database based on the reference ID
$mock_items = [
    ['name' => 'ផលិតផលឆ្មា (Deluxe Catnip)', 'quantity' => 2, 'price' => 5.00],
    ['name' => 'អាហារឆ្មាពិសេស (Premium Food)', 'quantity' => 1, 'price' => 10.75],
    ['name' => 'ប្រដាប់កោសក្រចក (Scratching Post)', 'quantity' => 1, 'price' => 50.00]
];

$subtotal = 0;
foreach ($mock_items as $item) {
    $subtotal += $item['price'] * $item['quantity'];
}

$shipping_fee = 5.00;
$total_due = $subtotal + $shipping_fee;

$customer_info = [
    'name' => 'អ្នកស្រី ពេជ្រ',
    'address' => 'ផ្ទះលេខ ៩៩, ផ្លូវ ០០, ភ្នំពេញ, កម្ពុជា',
    'phone' => '+855 99 888 777',
];
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>វិក្កយបត្រ #<?php echo htmlspecialchars($invoice_id); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --success-color: #28a745;
            --card-background: #ffffff;
            --border-radius: 12px;
            --shadow-heavy: 0 10px 30px rgba(0, 0, 0, 0.15);
            --text-color: #333;
            --light-text-color: #666;
            --danger-color: #e63946;
        }
        
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif;
            background-color: #f4f6f9;
            color: var(--text-color);
            padding: 20px;
        }
        
        .container {
            width: 90%; max-width: 900px; margin: 0 auto;
        }

        /* ======================================= */
        /* --- INVOICE CONTAINER --- */
        /* ======================================= */
        .invoice-container {
            background-color: var(--card-background);
            padding: 40px;
            border-radius: 15px;
            box-shadow: var(--shadow-heavy);
            border-top: 10px solid var(--primary-color); /* Bold primary accent */
        }
        
        /* Header */
        .invoice-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 40px;
        }
        .invoice-header .logo-text h1 {
            color: var(--primary-color);
            font-size: 2.5em;
            margin: 0;
        }
        .invoice-header .logo-text p {
             font-size: 0.9em;
             color: var(--light-text-color);
        }
        
        .invoice-header .details {
            text-align: right;
            line-height: 1.6;
        }
        .invoice-header .details h2 {
            font-size: 1.5em;
            color: var(--secondary-color);
            margin: 0 0 10px 0;
        }

        /* Billing and Shipping Info */
        .info-section {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            padding: 15px 0;
            border-bottom: 1px dashed #ddd;
        }

        .info-card {
            width: 45%;
            background-color: #f8f8f8;
            padding: 15px;
            border-left: 5px solid var(--secondary-color);
            border-radius: 8px;
        }
        
        .info-card h4 {
            margin-top: 0;
            color: var(--primary-color);
            font-size: 1.1em;
            padding-bottom: 5px;
            margin-bottom: 10px;
        }
        
        /* Order Items Table */
        .order-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 40px;
        }
        
        .order-table th, .order-table td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            text-align: left;
        }

        .order-table th {
            background-color: var(--primary-color);
            color: var(--secondary-color);
            text-align: center;
            font-weight: bold;
        }

        .order-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .item-qty, .item-price, .item-total {
             text-align: center;
        }
        
        /* Totals Area */
        .invoice-totals {
            display: flex;
            justify-content: flex-end;
        }

        .totals-box {
            width: 350px;
            border: 2px solid var(--primary-color);
            padding: 20px;
            border-radius: var(--border-radius);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        
        .totals-box div {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dotted #eee;
        }
        
        .totals-box .total {
            font-size: 1.5em;
            font-weight: 900;
            color: var(--danger-color); /* Bold red for final amount */
            padding-top: 15px;
            border-bottom: none;
        }
        
        .totals-box .total span {
            color: var(--primary-color);
        }
        
        /* Action Buttons */
        .print-area {
            text-align: center;
            margin-top: 40px;
        }
        
        .print-btn {
            background-color: var(--success-color);
            color: white;
            padding: 15px 30px;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            font-size: 1.2em;
            font-weight: bold;
            transition: all 0.3s ease;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .print-btn:hover {
            background-color: #1e7e34;
            transform: translateY(-2px);
        }

        /* --- Print Styles --- */
        @media print {
            body { background-color: white !important; padding: 0 !important; }
            .print-area, header { display: none !important; } /* Hide buttons and header */
            .invoice-container { box-shadow: none !important; margin: 0; padding: 0; border-top: none; }
            .order-table th { background-color: #eee !important; -webkit-print-color-adjust: exact; }
        }
        
        /* --- Responsive Styles (Mobile) --- */
        @media (max-width: 768px) {
            .invoice-container { margin: 10px; padding: 20px; }
            .invoice-header { flex-direction: column; align-items: center; text-align: center; }
            .invoice-header .details { text-align: center; margin-top: 15px; }
            .info-section { flex-direction: column; gap: 20px; }
            .info-card { width: 100%; }
            .order-table th, .order-table td { padding: 8px; font-size: 0.9em; }
            .invoice-totals { justify-content: center; }
            .totals-box { width: 100%; }
        }
    </style>
</head>
<body>

<div class="container invoice-container">
    
    <div class="invoice-header">
        <div class="logo-text">
            <h1>MODERN SHOP8</h1>
            <p>ហាងលក់ទំនិញទំនើបសម្រាប់អ្នក!</p>
        </div>
        <div class="details">
            <h2>វិក្កយបត្រ (Invoice)</h2>
            <p>លេខវិក្កយបត្រ: <strong><?php echo htmlspecialchars($invoice_id); ?></strong></p>
            <p>លេខយោង: <strong><?php echo htmlspecialchars($reference_id); ?></strong></p>
            <p>កាលបរិច្ឆេទ: <?php echo htmlspecialchars(date('d/M/Y', strtotime($invoice_date))); ?></p>
        </div>
    </div>

    <div class="info-section">
        <div class="info-card">
            <h4><i class="fas fa-user-circle"></i> ព័ត៌មានអតិថិជន</h4>
            <p><strong>ឈ្មោះ:</strong> <?php echo htmlspecialchars($customer_info['name']); ?></p>
            <p><strong>ទូរស័ព្ទ:</strong> <?php echo htmlspecialchars($customer_info['phone']); ?></p>
        </div>
        <div class="info-card">
            <h4><i class="fas fa-shipping-fast"></i> ព័ត៌មានដឹកជញ្ជូន</h4>
            <p><strong>អាសយដ្ឋាន:</strong> <?php echo htmlspecialchars($customer_info['address']); ?></p>
            <p><strong>ស្ថានភាព:</strong> <span style="color:var(--success-color); font-weight:bold;">បានបង់/បញ្ចប់</span></p>
        </div>
    </div>

    <table class="order-table">
        <thead>
            <tr>
                <th style="width: 45%;"><i class="fas fa-box"></i> ផលិតផល</th>
                <th style="width: 20%;">តម្លៃឯកតា</th>
                <th style="width: 10%;">ចំនួន</th>
                <th style="width: 25%;">តម្លៃសរុប</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($mock_items as $item): 
                $line_total = $item['price'] * $item['quantity'];
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td class="item-price">$<?php echo htmlspecialchars(number_format($item['price'], 2)); ?></td>
                    <td class="item-qty"><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td class="item-total"><strong>$<?php echo htmlspecialchars(number_format($line_total, 2)); ?></strong></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="invoice-totals">
        <div class="totals-box">
            <div>
                <span>តម្លៃរង (Subtotal):</span>
                <span>$<?php echo htmlspecialchars(number_format($subtotal, 2)); ?></span>
            </div>
            <div>
                <span>ថ្លៃដឹកជញ្ជូន (Shipping):</span>
                <span>$<?php echo htmlspecialchars(number_format($shipping_fee, 2)); ?></span>
            </div>
            <div class="total">
                <span>សរុបដែលត្រូវបង់:</span>
                <span>$<?php echo htmlspecialchars(number_format($total_due, 2)); ?></span>
            </div>
        </div>
    </div>
    
    <div class="print-area">
        <button class="print-btn" onclick="window.print()">
            <i class="fas fa-print"></i> បោះពុម្ពវិក្កយបត្រ
        </button>
    </div>
    
    <div style="text-align: center; margin-top: 30px; padding-top: 20px; border-top: 1px dashed var(--light-text-color);">
        <p style="color: var(--light-text-color); font-size: 0.9em;">
             <i class="fas fa-heart"></i> សូមអរគុណដែលបានទិញទំនិញពីយើង!
        </p>
    </div>
</div>

</body>
</html>
