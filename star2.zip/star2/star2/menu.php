<?php
// menu.php - reusable menubar
// This file expects that `database.php` (or another bootstrap) has already called session_start()
// If not, it will safely start a session.
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<header class="site-header">
    <div class="container nav-container">
        <div class="brand">
            <a href="index.php">MODERN SHOP8</a>
        </div>

        <button class="nav-toggle" aria-label="Open navigation" aria-expanded="false">☰</button>

        <nav class="main-nav" id="main-nav">
            <ul>
                <li><a href="index.php">ទំព័រដើម</a></li>
                <li><a href="about.php">អំពីយើង</a></li>
                <li><a href="cart.php">រទេះទិញទំនិញ</a></li>
                <li><a href="history.php">ប្រវត្តិការទិញ</a></li>
                <li><a href="contact.php">ទំនាក់ទំនង</a></li>

                <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                    <li><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                    <li><a href="logout.php">ចាកចេញ</a></li>
                <?php else: ?>
                    <li><a href="admin_login.php">ចូលជាអ្នកគ្រប់គ្រង</a></li>
                <?php endif; ?>
            </ul>
        </nav>

        <!-- Right-side CTA button -->
        <div class="header-cta">
            <a href="cart.php" class="btn header-btn" aria-label="View cart">
                <i class="fas fa-shopping-cart"></i>
                <span class="btn-text">រទេះទិញ</span>
            </a>
        </div>
    </div>
</header>

<script>
// Small JS to handle mobile nav toggle
document.addEventListener('DOMContentLoaded', function() {
    var btn = document.querySelector('.nav-toggle');
    var nav = document.getElementById('main-nav');
    if (!btn || !nav) return;
    btn.addEventListener('click', function() {
        var expanded = this.getAttribute('aria-expanded') === 'true';
        this.setAttribute('aria-expanded', (!expanded).toString());
        nav.classList.toggle('open');
    });
});
</script>
