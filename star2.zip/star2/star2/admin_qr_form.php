<?php
// admin_qr_form.php - ទំព័រសម្រាប់គ្រប់គ្រងការកំណត់ QR Code (FUN STYLE)
include 'database.php';

// ចាប់ផ្តើម session ប្រសិនបើមិនទាន់ (ចាំបាច់សម្រាប់ admin check)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current script name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']); 

// ពិនិត្យមើលថាតើអ្នកប្រើប្រាស់បានចូលជាអ្នកគ្រប់គ្រងឬអត់
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: admin_login.php');
    exit;
}

$success_message = '';
$error_message = '';

// គ្រប់គ្រងការដាក់ស្នើទម្រង់
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Allow admins to delete all QR settings in a single action
    if (isset($_POST['action']) && $_POST['action'] === 'delete_all') {
        try {
            $conn->begin_transaction();
            $res = $conn->query("DELETE FROM qr_settings");
            if ($res) {
                $conn->commit();
                $success_message = 'បានលុប QR Code ទាំងអស់រួចរាល់។';
            } else {
                $conn->rollback();
                $error_message = 'មានបញ្ហាក្នុងការលុប: ' . htmlspecialchars($conn->error);
            }
        } catch (Exception $e) {
            if ($conn->connect_errno === 0) {
                $conn->rollback();
            }
            $error_message = 'កំហុស: ' . htmlspecialchars($e->getMessage());
        }
    } else {
        $updates = 0;
        $conn->begin_transaction();

        // ពិនិត្យមើលថាតើ 'qr' array ត្រូវបានកំណត់ឬអត់
        if (isset($_POST['qr']) && is_array($_POST['qr'])) {
            foreach ($_POST['qr'] as $id => $data) {
                $bank_name = trim($data['bank_name']);
                $account_name = trim($data['account_name']);
                $account_number = trim($data['account_number']);
                $qr_image_url = trim($data['qr_image_url']);

                // ត្រូវប្រាកដថា ID ជាលេខ ហើយ Field មិនទទេ
                if (is_numeric($id) && !empty($bank_name) && !empty($account_name) && !empty($account_number) && !empty($qr_image_url)) {
                    // កែប្រែដោយប្រើ Prepared Statement
                    $stmt = $conn->prepare("UPDATE qr_settings SET bank_name = ?, account_name = ?, account_number = ?, qr_image_url = ? WHERE id = ?");
                    if ($stmt) {
                        $stmt->bind_param("ssssi", $bank_name, $account_name, $account_number, $qr_image_url, $id);
                        if ($stmt->execute()) {
                            $updates++;
                        }
                        $stmt->close();
                    } else {
                        $error_message = 'មានបញ្ហាក្នុងការរៀបចំសំណួរ៖ ' . htmlspecialchars($conn->error);
                        $conn->rollback();
                        break;
                    }
                }
            }
        }
        
        if (empty($error_message)) {
            $conn->commit();
            if ($updates > 0) {
                $success_message = "បានកែប្រែ QR Code ចំនួន " . $updates . " ដោយជោគជ័យ!";
            } else {
                $error_message = "មិនមានការផ្លាស់ប្តូរត្រូវបានរក្សាទុកទេ។ សូមពិនិត្យមើលទម្រង់។";
            }
        } else {
             $conn->rollback();
        }
    }
}

// ហៅយកការកំណត់ QR ទាំងអស់
$sql = "SELECT * FROM qr_settings ORDER BY id ASC";
$result = $conn->query($sql);

$qr_settings = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $qr_settings[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>គ្រប់គ្រង QR Code</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --card-background: #ffffff;
            --border-radius: 8px;
            --shadow-heavy: 0 10px 30px rgba(0,0,0,0.15);
            --text-color: #333;
            --light-text-color: #666;
            --delete-button-bg: #e63946;
            --accent-purple: #9c27b0;
            --accent-green: #4caf50;
        }
        
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: var(--text-color);
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* ======================================= */
        /* --- HEADER & NAVIGATION (FUN/RESPONSIVE) --- */
        /* ======================================= */
        header { background-color: var(--primary-color); padding: 15px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        header .navbar {
            display: flex; justify-content: space-between; align-items: center; width: 90%; max-width: 1200px; margin: auto; flex-wrap: wrap; 
        }
        .brand-logo { display: flex; align-items: center; gap: 10px; order: 1; }
        .brand-logo img { height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px; }
        .brand-text { display: flex; flex-direction: column; color: #fff; line-height: 1.2; }
        .brand-text h1 { font-size: 1.5em; margin: 0; font-weight: bold; }
        .brand-text p { font-size: 0.8em; margin: 0; opacity: 0.8; }
        header nav ul {
            list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; order: 3; width: 100%; justify-content: flex-end;
        }
        header nav ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header nav ul li a:hover,
        header nav ul li.active-link a {
            color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle { display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2; }
        
        /* Mobile Menu */
        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            header .navbar ul { display: none; flex-direction: column; order: 4; background-color: #005660; }
            header .navbar ul.open { display: flex; }
            .brand-logo { flex-direction: column; align-items: flex-start; gap: 2px; }
        }

        /* Dashboard Title */
        .qr-form-container h2 {
            font-size: 2em;
            color: var(--primary-color);
            border-bottom: 3px solid var(--secondary-color);
            padding-bottom: 10px;
            margin-top: 0;
            margin-bottom: 30px;
            text-align: center;
        }
        
        /* ======================================= */
        /* --- QR FORM SPECIFIC FUN STYLE --- */
        /* ======================================= */
        .qr-form-container {
            max-width: 900px;
            margin: 50px auto;
            background-color: var(--card-background);
            padding: 40px;
            border-radius: 15px; /* More rounded */
            box-shadow: var(--shadow-heavy);
        }
        .qr-bank-section {
            border: 2px solid var(--secondary-color); /* Highlight bank section */
            border-left: 8px solid var(--primary-color);
            padding: 20px;
            margin-bottom: 30px;
            border-radius: 10px;
            background-color: #fcfcfc;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        .qr-bank-section:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        }
        .qr-bank-section h3 {
            font-size: 1.5em;
            color: var(--accent-purple); /* Bold color for bank name */
            border-bottom: 2px dotted var(--secondary-color);
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .form-group label {
            font-weight: bold;
            color: var(--primary-color);
            margin-bottom: 5px;
            display: block;
        }
        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }
        .form-group input:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 5px rgba(255, 209, 102, 0.5);
        }
        .img-preview {
            max-width: 150px;
            height: auto;
            display: block;
            margin-top: 10px;
            border: 3px solid var(--accent-green); /* Fun border */
            padding: 5px;
            border-radius: 5px;
            transition: transform 0.3s;
        }
        .img-preview:hover {
            transform: scale(1.05);
        }

        /* Buttons */
        .btn-submit-all {
            width: 100%;
            background-color: var(--accent-green);
            color: white;
            border: none;
            padding: 15px;
            font-size: 1.1em;
            cursor: pointer;
            border-radius: 50px; /* Pill shape */
            font-weight: bold;
            transition: all 0.3s ease;
            margin-top: 20px;
        }
        .btn-submit-all:hover {
            background-color: #388e3c;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            transform: translateY(-2px);
        }
        .btn-delete-all {
            background-color: var(--delete-button-bg);
            color: white;
            padding: 10px 20px;
            border-radius: 50px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn-delete-all:hover {
            background-color: #b82333;
            transform: scale(1.05);
        }
        .btn-back-admin {
            background-color: var(--primary-color);
            color: white;
            padding: 10px 20px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn-back-admin:hover {
            background-color: #004d53;
        }

        /* Messages */
        .message-success { color: var(--accent-green); text-align: center; font-weight: bold; margin-bottom: 20px;}
        .message-error { color: var(--delete-button-bg); text-align: center; font-weight: bold; margin-bottom: 20px;}
    </style>
</head>
<body>
    <header>
        <div class="container navbar">
            <div class="brand-logo">
                <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
                <div class="brand-text">
                    <h1>MODERN SHOP8</h1>
                    <p>គ្រប់គ្រង QR</p> 
                </div>
            </div>
            
            <div class="menu-toggle" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>

            <nav>
                <ul id="admin-menu">
                    <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">ផលិតផល</a></li>
                    <li class="<?php echo ($current_page == 'admin_contacts.php') ? 'active-link' : ''; ?>"><a href="admin_contacts.php">ទំនាក់ទំនង</a></li>
                    <li class="<?php echo ($current_page == 'admin_qr_form.php') ? 'active-link' : ''; ?>"><a href="admin_qr_form.php">QR Code</a></li>
                    <li><a href="logout.php">ចាកចេញ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container qr-form-container">
        <h2><i class="fas fa-qrcode" style="color: var(--secondary-color);"></i> គ្រប់គ្រង QR Code សម្រាប់ទូទាត់</h2>

        <?php if ($success_message): ?>
            <p class="message-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?></p>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <p class="message-error"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
        
        <?php if (empty($qr_settings)): ?>
            <p style="text-align: center; color: var(--delete-button-bg); font-size: 1.1em; padding: 20px;">
                ⚠️ មិនមានការកំណត់ QR Code នៅក្នុងមូលដ្ឋានទិន្នន័យទេ។ សូមបញ្ចូលកំណត់ត្រាដោយផ្ទាល់ទៅក្នុងតារាង `qr_settings` ដើម្បីចាប់ផ្តើមគ្រប់គ្រង។
            </p>
        <?php else: ?>
            <form method="POST" action="admin_qr_form.php">
                <?php foreach ($qr_settings as $setting): ?>
                    <div class="qr-bank-section">
                        <h3><i class="fas fa-university"></i> <?php echo htmlspecialchars($setting['bank_name']); ?></h3>
                        <input type="hidden" name="qr[<?php echo htmlspecialchars($setting['id']); ?>][id]" value="<?php echo htmlspecialchars($setting['id']); ?>">
                        
                        <div class="form-group">
                            <label for="bank_name_<?php echo htmlspecialchars($setting['id']); ?>">ឈ្មោះធនាគារ:</label>
                            <input type="text" id="bank_name_<?php echo htmlspecialchars($setting['id']); ?>" name="qr[<?php echo htmlspecialchars($setting['id']); ?>][bank_name]" value="<?php echo htmlspecialchars($setting['bank_name']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="account_name_<?php echo htmlspecialchars($setting['id']); ?>">ឈ្មោះគណនី:</label>
                            <input type="text" id="account_name_<?php echo htmlspecialchars($setting['id']); ?>" name="qr[<?php echo htmlspecialchars($setting['id']); ?>][account_name]" value="<?php echo htmlspecialchars($setting['account_name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="account_number_<?php echo htmlspecialchars($setting['id']); ?>">លេខគណនី:</label>
                            <input type="text" id="account_number_<?php echo htmlspecialchars($setting['id']); ?>" name="qr[<?php echo htmlspecialchars($setting['id']); ?>][account_number]" value="<?php echo htmlspecialchars($setting['account_number']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="qr_image_url_<?php echo htmlspecialchars($setting['id']); ?>">តំណភ្ជាប់រូបភាព QR (URL):</label>
                            <input type="text" id="qr_image_url_<?php echo htmlspecialchars($setting['id']); ?>" name="qr[<?php echo htmlspecialchars($setting['id']); ?>][qr_image_url]" value="<?php echo htmlspecialchars($setting['qr_image_url']); ?>" required>
                            <img src="<?php echo htmlspecialchars($setting['qr_image_url']); ?>" alt="Current QR Code" class="img-preview">
                        </div>
                    </div>
                <?php endforeach; ?>

                <button type="submit" class="btn-submit-all"><i class="fas fa-save"></i> រក្សាទុកការកំណត់ QR ទាំងអស់</button>
            </form>
            
            <hr style="margin: 30px 0; border-top: 1px dashed #ccc;">

            <div style="text-align: center; margin-top: 10px;">
                <form method="POST" onsubmit="return confirm('តើអ្នកប្រាកដ ឬ? ការលុបនេះនឹងលុបទាំងអស់នៃកំណត់ត្រា QR ហើយមិនអាចដកវិញបាន។');">
                    <input type="hidden" name="action" value="delete_all">
                    <button type="submit" class="btn btn-delete-all"><i class="fas fa-minus-circle"></i> លុប QR ទាំងអស់</button>
                </form>
            </div>
        <?php endif; ?>
        
        <div style="text-align: center; margin-top: 40px;">
            <a href="admin.php" class="btn-back-admin"><i class="fas fa-arrow-left"></i> ត្រលប់ទៅផ្ទាំងគ្រប់គ្រង</a>
        </div>
    </div>
    
    <script>
        function toggleMenu() {
            var menu = document.getElementById('admin-menu');
            menu.classList.toggle('open');
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>