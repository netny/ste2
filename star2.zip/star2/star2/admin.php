<?php
// admin.php - ផ្ទាំងគ្រប់គ្រងសម្រាប់អ្នកគ្រប់គ្រង (កំណែ FUN STYLE)
include 'database.php';

// ចាប់ផ្តើម session ប្រសិនបើមិនទាន់ (ចាំបាច់សម្រាប់ admin check)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current script name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']); 

// ពិនិត្យមើលថាតើអ្នកប្រើប្រាស់បានចូលជាអ្នកគ្រប់គ្រងឬអត់
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: admin_login.php');
    exit;
}

// គ្រប់គ្រងសកម្មភាពលុប
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $product_id = intval($_GET['delete']);
    
    // លុបផលិតផលចេញពីមូលដ្ឋានទិន្នន័យ
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $stmt->close();
    }

    header('Location: admin.php');
    exit;
}

// ហៅយកផលិតផលទាំងអស់
$sql = "SELECT * FROM products ORDER BY id DESC";
$result = $conn->query($sql);

$products = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ផ្ទាំងគ្រប់គ្រង</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --accent-green: #5cb85c;
            --accent-blue: #007bff;
            --accent-red: #e63946;
            --card-background: #ffffff;
            --shadow-light: 0 4px 6px rgba(0,0,0,0.1);
            --shadow-heavy: 0 8px 15px rgba(0,0,0,0.2);
            --delete-button-bg: var(--accent-red);
            --text-color: #333;
        }
        
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: var(--text-color);
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* ======================================= */
        /* --- HEADER & NAVIGATION (FUN/RESPONSIVE) --- */
        /* ======================================= */
        header {
            background-color: var(--primary-color);
            padding: 15px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .brand-logo {
            display: flex; align-items: center; gap: 10px; order: 1;
        }
        .brand-logo img {
            height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px;
        }
        .brand-text {
            display: flex; flex-direction: column; color: #fff; line-height: 1.2;
        }
        .brand-text h1 { font-size: 1.5em; margin: 0; font-weight: bold; }
        .brand-text p { font-size: 0.8em; margin: 0; opacity: 0.8; }

        header nav { order: 3; width: 100%; }
        header nav ul {
            list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; justify-content: flex-end;
        }
        header nav ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header nav ul li a:hover,
        header nav ul li.active-link a {
            color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle { display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2; }
        
        /* Dashboard Title */
        .container h2 {
            font-size: 2em;
            color: var(--primary-color);
            border-bottom: 3px solid var(--secondary-color);
            padding-bottom: 10px;
            margin-top: 30px;
            margin-bottom: 30px;
            text-align: center;
        }

        /* ======================================= */
        /* 2. ADMIN CONTROLS (FUN STYLE TILES) */
        /* ======================================= */
        .admin-controls {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }
        .admin-controls-group {
            display: flex;
            flex-wrap: wrap;
            gap: 20px; /* Increased gap for visual space */
            justify-content: center;
        }
        .admin-controls-group a {
            display: inline-flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 15px 25px;
            min-width: 150px;
            height: 120px; /* Fixed height for tile effect */
            text-decoration: none;
            border-radius: 10px;
            font-size: 1em;
            font-weight: bold;
            color: white;
            box-shadow: 0 4px 10px rgba(0,0,0,0.15);
            transition: all 0.3s ease;
            text-align: center;
        }
        .admin-controls-group a i {
            font-size: 2.2em;
            margin-bottom: 10px;
        }
        .admin-controls-group a:hover {
            transform: translateY(-5px) scale(1.05); /* Fun lift effect */
            box-shadow: 0 8px 15px rgba(0,0,0,0.3);
        }

        /* Specific Button Colors for Fun/Clarity */
        .btn-add-product { background-color: var(--accent-blue); }
        .btn-add-product:hover { background-color: #0056b3; }
        
        .btn-view-contacts { background-color: #17a2b8; }
        .btn-view-contacts:hover { background-color: #117a8b; }
        
        .btn-qr-code { background-color: var(--secondary-color); color: var(--primary-color) !important; }
        .btn-qr-code:hover { background-color: #ffb300; }
        
        .btn-orders { background-color: var(--accent-green); }
        .btn-orders:hover { background-color: #4cae4c; }

        /* ======================================= */
        /* 3. RESPONSIVE TABLE STYLES (FUN) */
        /* ======================================= */
        .admin-table {
            border-radius: 10px;
            overflow: hidden; /* Important for border-radius on table */
            box-shadow: var(--shadow-heavy);
        }
        .admin-table th {
            background-color: var(--primary-color);
            color: var(--secondary-color); /* Highlight headers */
            font-weight: 800;
            text-transform: uppercase;
        }
        .admin-table td {
            font-size: 0.95em;
            vertical-align: middle;
        }
        .admin-table tbody tr {
            transition: background-color 0.3s;
        }
        .admin-table tbody tr:hover {
            background-color: #e0f7fa !important; /* Light accent hover */
        }
        .admin-actions a.btn {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .btn-edit { background-color: var(--accent-blue); color: white; }
        .btn-edit:hover { background-color: #0056b3; }
        .btn-remove { background-color: var(--delete-button-bg); color: white; }
        .btn-remove:hover { background-color: #b82333; }
        
        .admin-table img {
            border: 2px solid var(--secondary-color); /* Fun border around image */
            border-radius: 5px;
        }
        
        /* Mobile specific media queries from previous step */
        @media (max-width: 768px) {
            /* Table Card Layout */
            .admin-table td:nth-of-type(1):before { content: "លេខសម្គាល់:"; }
            .admin-table td:nth-of-type(2):before { content: "រូបភាព:"; }
            .admin-table td:nth-of-type(3):before { content: "ឈ្មោះ:"; }
            .admin-table td:nth-of-type(4):before { content: "តម្លៃ:"; }
            .admin-table td:nth-of-type(5):before { content: "សកម្មភាព:"; }
            
            /* Admin Controls stack and stretch */
            .admin-controls-group {
                flex-direction: column;
                align-items: stretch;
            }
            .admin-controls-group a {
                min-width: unset;
                height: unset;
                padding: 15px;
                text-align: left;
                flex-direction: row;
                justify-content: flex-start;
            }
            .admin-controls-group a i {
                margin-bottom: 0;
                margin-right: 15px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="brand-logo">
                <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
                <div class="brand-text">
                    <h1>MODERN SHOP8</h1>
                    <p>ផ្ទាំងគ្រប់គ្រង</p> 
                </div>
            </div>
            
            <div class="menu-toggle" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>

            <nav>
                <ul id="admin-menu">
                    <li class="<?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>"><a href="index.php">ទៅកាន់ទំព័រដើម</a></li>
                    <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">គ្រប់គ្រងផលិតផល</a></li>
                    <li><a href="logout.php">ចាកចេញ</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <h2><i class="fas fa-tools" style="color: var(--secondary-color);"></i> ផ្ទាំងគ្រប់គ្រង</h2>
        
        <div class="admin-controls">
            <div class="admin-controls-group">
                <a href="admin_product_form.php" class="btn btn-add-product">
                    <i class="fas fa-plus-circle"></i> បន្ថែមផលិតផលថ្មី
                </a>
                <a href="admin_contacts.php" class="btn btn-view-contacts">
                    <i class="fas fa-envelope"></i> មើលសារទំនាក់ទំនង
                </a>
                <a href="history.php" class="btn btn-orders">
                    <i class="fas fa-clipboard-list"></i> មើលបញ្ជីការបញ្ជាទិញ
                </a>
            </div>
        </div>

        <table class="admin-table">
            <thead>
                <tr>
                    <th>លេខសម្គាល់</th>
                    <th>រូបភាព</th>
                    <th>ឈ្មោះ</th>
                    <th>តម្លៃ</th>
                    <th>សកម្មភាព</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($products)): ?>
                    <tr>
                        <td colspan="5" style="text-align: center;">មិនមានផលិតផលណាមួយត្រូវបានរកឃើញទេ។</td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td data-label="លេខសម្គាល់"><?php echo htmlspecialchars($product['id']); ?></td>
                        <td data-label="រូបភាព">
                            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" alt="Product Image" style="width: 80px; height: auto;">
                        </td>
                        <td data-label="ឈ្មោះ"><?php echo htmlspecialchars($product['name']); ?></td>
                        <td data-label="តម្លៃ">**$<?php echo htmlspecialchars(number_format($product['price'], 2)); ?>**</td>
                        <td data-label="សកម្មភាព" class="admin-actions">
                            <a href="admin_product_form.php?id=<?php echo htmlspecialchars($product['id']); ?>" class="btn btn-edit">
                                <i class="fas fa-edit"></i> កែប្រែ
                            </a>
                            <a href="admin.php?delete=<?php echo htmlspecialchars($product['id']); ?>" class="btn btn-remove" onclick="return confirm('តើអ្នកពិតជាចង់លុបផលិតផលនេះមែនទេ?');">
                                <i class="fas fa-trash-alt"></i> លុប
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <script>
        function toggleMenu() {
            var menu = document.getElementById('admin-menu');
            menu.classList.toggle('open');
        }
    </script>
</body>
</html>
<?php
$conn->close();
?>