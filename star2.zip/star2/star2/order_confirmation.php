<?php
// order_confirmation.php - ទំព័រដើម្បីកត់ត្រាការបញ្ជាទិញទៅក្នុងមូលដ្ឋានទិន្នន័យ និងបញ្ចប់ការទិញ

// រួមបញ្ចូលការតភ្ជាប់មូលដ្ឋានទិន្នន័យ (database.php នឹងចាប់ផ្តើម session និង $conn)
include 'database.php';

// Check if transaction reference ID is provided and cart is NOT empty
$ref_id = isset($_GET['ref']) ? $_GET['ref'] : null;
$cart_has_items = isset($_SESSION['cart']) && !empty($_SESSION['cart']);
$total_price = 0;

if (!$ref_id && !$cart_has_items) {
    // If no reference or empty cart, redirect back to cart for safety.
    // If cart is cleared but ref_id is present, we still allow viewing the confirmation.
    header('Location: cart.php');
    exit;
}

// =========================================================
// --- 1. CALCULATE FINAL TOTAL ---
// =========================================================

if ($cart_has_items) {
    foreach ($_SESSION['cart'] as $item) {
        $total_price += $item['price'] * $item['quantity'];
    }
} else {
    // If cart is empty, use 0.00 for display unless the order was just recorded (handled by logic below)
    $total_price = 0.00;
}

// =========================================================
// --- 2. RECORD ORDER & ITEMS (FINALIZATION) ---
// --- Only record if there are items in the cart (meaning it hasn't been done yet) ---
// =========================================================

$order_success = false;
$new_order_id = null;
$current_order_total = $total_price;

// Only execute recording logic if the cart is NOT empty (meaning this is the first time visiting after checkout)
if ($cart_has_items) {
    // Start transaction to ensure atomicity
    $conn->begin_transaction();

    try {
        // A. Insert into orders table
        $stmt_order = $conn->prepare("INSERT INTO orders (total_price, purchase_date, transaction_ref) VALUES (?, NOW(), ?)");
        // Use the actual total price and reference ID
        $stmt_order->bind_param("ds", $current_order_total, $ref_id);
        $stmt_order->execute();
        $new_order_id = $conn->insert_id;
        $stmt_order->close();

        // B. Insert items into order_items table
        $stmt_item = $conn->prepare("INSERT INTO order_items (order_id, product_name, quantity, price) VALUES (?, ?, ?, ?)");

        foreach ($_SESSION['cart'] as $product_id => $item) {
            $stmt_item->bind_param("isid", $new_order_id, $item['name'], $item['quantity'], $item['price']);
            $stmt_item->execute();
        }
        $stmt_item->close();

        // C. Commit the transaction
        $conn->commit();
        $order_success = true;

        // D. Clear session variables after successful order
        unset($_SESSION['cart']);
        unset($_SESSION['cat_transaction_id']);

        // Set persistent data for display only
        $_SESSION['last_order'] = [
            'id' => $new_order_id,
            'ref' => $ref_id,
            'total' => $current_order_total,
            'success' => true
        ];

    } catch (mysqli_sql_exception $e) {
        // If any error occurs, rollback and log
        $conn->rollback();
        error_log("Order failed to record: " . $e->getMessage());
        $order_success = false;
    }
} else if (isset($_SESSION['last_order']) && $_SESSION['last_order']['ref'] === $ref_id) {
    // If the cart is empty but a successful order was just placed (user refreshes page)
    $order_success = $_SESSION['last_order']['success'];
    $new_order_id = $_SESSION['last_order']['id'];
    $current_order_total = $_SESSION['last_order']['total'];
} else {
    // Fallback if transaction ID is wrong or order was never placed
    $order_success = false;
}


// Get the current script name for active link highlighting (for the header)
$current_page = basename($_SERVER['PHP_SELF']); 
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];

// Set confirmation message details
$confirmation_message = $order_success ? "ការទិញត្រូវបានបញ្ចប់ដោយជោគជ័យ!" : "ការទិញមិនបានជោគជ័យទេ។ សូមពិនិត្យមើលប្រវត្តិ។";
$icon_class = $order_success ? 'fas fa-check-circle' : 'fas fa-times-circle';
$color_var = $order_success ? 'var(--success-color)' : 'var(--delete-color)';
$order_number = $order_success ? $new_order_id : 'N/A';
$total_price_display = $order_success ? $current_order_total : 0.00;

?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>បញ្ជាក់ការទិញ</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Shared Styles */
        :root {
            --primary-color: #006d77;
            --secondary-color: #ffd166;
            --success-color: #28a745;
            --delete-color: #dc3545;
            --card-background: #ffffff;
            --border-radius: 12px;
            --shadow-heavy: 0 10px 30px rgba(0, 0, 0, 0.15);
            --text-color: #333;
        }
        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif;
            background-color: #f4f6f9;
            color: var(--text-color);
            padding-top: 20px;
        }
        .container {
            width: 90%; max-width: 700px; margin: 0 auto;
        }
        
        /* ======================================= */
        /* --- HEADER & NAVIGATION (FUN/RESPONSIVE) --- */
        /* ======================================= */
        header { background-color: var(--primary-color); padding: 15px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        header .navbar {
            display: flex; justify-content: space-between; align-items: center; width: 90%; max-width: 1200px; margin: auto; flex-wrap: wrap; 
        }
        .brand-logo { display: flex; align-items: center; gap: 10px; order: 1; }
        .brand-logo img { height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px; }
        .brand-text { display: flex; flex-direction: column; color: #fff; line-height: 1.2; }
        .brand-text h1 { font-size: 1.5em; margin: 0; font-weight: bold; }
        .brand-text p { font-size: 0.8em; margin: 0; opacity: 0.8; }
        header nav ul {
            list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; order: 3; width: 100%; justify-content: flex-end;
        }
        header nav ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header nav ul li a:hover,
        header nav ul li.active-link a {
            color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color);
        }
        .menu-toggle { display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2; }
        
        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            header .navbar ul { display: none; flex-direction: column; order: 4; background-color: #005660; }
            header .navbar ul.open { display: flex; }
            .brand-logo { flex-direction: column; align-items: flex-start; gap: 2px; }
        }

        /* Confirmation Box Styling */
        .confirmation-box {
            background: var(--card-background); 
            padding: 40px; border-radius: var(--border-radius); 
            box-shadow: var(--shadow-heavy); 
            text-align: center; margin-top: 50px;
            border: 5px solid <?php echo $color_var; ?>;
        }

        .confirmation-box h2 {
            font-size: 2.2em;
            color: <?php echo $color_var; ?>;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }
        .confirmation-box p {
            font-size: 1.1em;
            margin-bottom: 30px;
            color: var(--text-color);
        }

        .order-details {
            background-color: #f7f7f7;
            padding: 20px;
            border-radius: 8px;
            text-align: left;
            margin-bottom: 30px;
            border-left: 5px solid var(--secondary-color);
        }

        .order-details p {
            margin: 10px 0;
            font-size: 1em;
        }

        .order-details strong {
            color: var(--primary-color);
        }

        .btn-action {
            background-color: var(--primary-color); 
            color: white; 
            padding: 12px 25px; 
            border-radius: 50px; 
            text-decoration: none; 
            font-weight: bold; 
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        .btn-action:hover {
            transform: translateY(-2px);
            background-color: var(--secondary-color);
            color: var(--primary-color);
            box-shadow: 0 6px 12px rgba(0,0,0,0.2);
        }

        @media (max-width: 480px) {
            .confirmation-box {
                padding: 20px;
            }
            .confirmation-box h2 {
                font-size: 1.5em;
                flex-direction: column;
            }
        }
    </style>
</head>
<body>

<!-- Header/Navigation Structure (copied from other files for consistency) -->
<header>
    <div class="navbar">
        <div class="brand-logo">
            <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
            <div class="brand-text">
                <h1>MODERN SHOP8</h1>
                <p>ហាងលក់ទំនិញទំនើបសម្រាប់អ្នក!</p> 
            </div>
        </div>
        
        <div class="menu-toggle" onclick="toggleMenu()">
            <i class="fas fa-bars"></i>
        </div>

        <nav>
            <ul id="main-menu">
                <li class="<?php echo ($current_page == 'index.php') ? 'active-link' : ''; ?>"><a href="index.php">ទំព័រដើម</a></li>
                <li class="<?php echo ($current_page == 'cart.php') ? 'active-link' : ''; ?>"><a href="cart.php">រទេះទិញទំនិញ</a></li>
                <li class="<?php echo ($current_page == 'history.php') ? 'active-link' : ''; ?>"><a href="history.php">ប្រវត្តិការទិញ</a></li>
                <li class="<?php echo ($current_page == 'contact.php') ? 'active-link' : ''; ?>"><a href="contact.php">ទំនាក់ទំនង</a></li>
                
                <?php if ($is_admin): ?>
                    <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                    <li><a href="logout.php">ចាកចេញ</a></li>
                <?php else: ?>
                    <li class="<?php echo ($current_page == 'admin_login.php') ? 'active-link' : ''; ?>"><a href="admin_login.php">ចូលជាអ្នកគ្រប់គ្រង</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>
<!-- End Header -->

<div class="container">
    <div class="confirmation-box">
        <h2>
            <i class="<?php echo $icon_class; ?>"></i> 
            <?php echo htmlspecialchars($confirmation_message); ?>
        </h2>

        <?php if ($order_success): ?>
            <p>សូមអរគុណសម្រាប់ការបញ្ជាទិញរបស់អ្នក។ យើងនឹងដំណើរការការបញ្ជាទិញនេះភ្លាមៗ។</p>
            <div class="order-details">
                <p><strong>លេខរៀងនៃការបញ្ជាទិញ:</strong> #<?php echo htmlspecialchars($order_number); ?></p>
                <p><strong>លេខសម្គាល់យោង (Ref ID):</strong> <?php echo htmlspecialchars($ref_id); ?></p>
                <p><strong>តម្លៃសរុប:</strong> $<?php echo htmlspecialchars(number_format($total_price_display, 2)); ?></p>
            </div>
        <?php else: ?>
            <p>សូមទាក់ទងមកកាន់ផ្នែកជំនួយអតិថិជនរបស់យើង ជាមួយនឹង **លេខសម្គាល់យោង (Ref ID: <?php echo htmlspecialchars($ref_id); ?>)** ដើម្បីដោះស្រាយបញ្ហា។</p>
        <?php endif; ?>

        <a href="index.php" class="btn-action">
            <i class="fas fa-home"></i> ត្រលប់ទៅទំព័រដើម
        </a>
        <a href="history.php" class="btn-action" style="background-color: var(--secondary-color); color: var(--primary-color);">
            <i class="fas fa-archive"></i> មើលប្រវត្តិ
        </a>
    </div>
</div>

<script>
    function toggleMenu() {
        const menu = document.getElementById('main-menu');
        menu.classList.toggle('open');
    }
</script>

</body>
</html>

<?php
// បិទការតភ្ជាប់បន្ទាប់ពីការដំណើរការ script ទាំងមូល
if (isset($conn)) {
    $conn->close();
}
?>
