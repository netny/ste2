<?php
// qr_scanner.php - ទំព័រទូទាត់ជាមួយ QR Code/ផ្ទេរតាមធនាគារ
include 'database.php';

// ចាប់ផ្តើមវគ្គ (Session) ប្រសិនបើវាមិនទាន់បានចាប់ផ្តើម
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// ពិនិត្យមើលថាតើរទេះទិញទំនិញទទេរឬអត់
if (empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}

// គណនាតម្លៃសរុប
$total_price = 0;
foreach ($_SESSION['cart'] as $item) {
    // ត្រូវប្រាកដថា 'price' និង 'quantity' មាន
    if (isset($item['price']) && isset($item['quantity'])) {
        $total_price += $item['price'] * $item['quantity'];
    }
}

// =========================================================
// ************** GENERATE TRANSACTION ID *************
// ពិនិត្យមើលថាតើ ID ប្រតិបត្តិការមានរួចហើយឬអត់។ បើអត់ទេ សូមបង្កើតថ្មី។
if (!isset($_SESSION['transaction_id'])) {
    // Generate a simple, unique 7-digit numeric ID for this transaction session.
    // In a real system, this would come from a database log or a unique ID service.
    // mt_rand is used for better randomness. str_pad ensures a 7-digit format (e.g., 0012345).
    $transaction_id = str_pad(mt_rand(1, 9999999), 7, '0', STR_PAD_LEFT);
    $_SESSION['transaction_id'] = $transaction_id;
} else {
    // Use the existing ID if it's already set for the current session.
    $transaction_id = $_SESSION['transaction_id'];
}
// =========================================================

// ហៅយកការកំណត់ QR ទាំងបីពីមូលដ្ឋានទិន្នន័យ
// តារាង qr_settings ត្រូវតែត្រូវបានបង្កើត (សូមយោងទៅជំហានទី 1 នៃការណែនាំមុន)
$sql_qr = "SELECT * FROM qr_settings ORDER BY id ASC";
$result_qr = $conn->query($sql_qr);
$qr_settings = [];
if ($result_qr && $result_qr->num_rows > 0) {
    while ($row = $result_qr->fetch_assoc()) {
        $qr_settings[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ទូទាត់ជាមួយ QR Code</title>
    <link rel="stylesheet" href="style.css">
    <style>
        /* Professional Bank/Payment Portal Styling */
        :root {
            --primary-color: #004c99; /* Deep Bank Blue */
            --secondary-color: #007bff; /* Accent Blue */
            --text-color: #333;
            --background-color: #f4f6f9; /* Light Gray Background */
            --card-background: #ffffff;
            --border-radius: 12px;
            --shadow-light: 0 4px 15px rgba(0, 0, 0, 0.08);
            --shadow-heavy: 0 8px 25px rgba(0, 0, 0, 0.15);
            --success-color: #28a745;
            --delete-button-bg: #dc3545; /* Added for consistency, though not used here */
        }
        body {
            font-family: 'Khmer OS Content', 'Khmer OS', 'Helvetica Neue', Helvetica, Arial, sans-serif; /* Keep Khmer font priority */
            background-color: var(--background-color);
            color: var(--text-color);
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            max-width: 1280px;
            margin: 0 auto;
        }
        /* Header Styling (Professional and clean) */
        header {
            background-color: var(--card-background);
            color: var(--primary-color);
            padding: 15px 0;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 {
            margin: 0;
            font-size: 1.8em;
            color: var(--primary-color);
        }
        header nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            gap: 20px;
        }
        header nav a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        header nav a:hover {
            color: var(--secondary-color);
        }

        /* Payment Box Container */
        .payment-box {
            background: linear-gradient(145deg, #ffffff, #f0f3f6); /* Gradient for depth */
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-heavy);
            max-width: 1200px;
            margin: 50px auto;
            text-align: center;
            border: 1px solid #e0e0e0;
        }
        .payment-box h2 {
            color: var(--primary-color);
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: 700;
        }
        .payment-info {
            font-size: 1.1em;
            margin-bottom: 40px;
            color: #6c757d;
        }

        /* Total Price Display */
        .total-display {
            padding: 15px 30px;
            background-color: #e9f7ee; /* Light green/success background */
            color: var(--success-color);
            border-radius: var(--border-radius);
            margin: 20px auto 40px;
            display: inline-block;
            font-size: 1.8em;
            font-weight: 700;
            box-shadow: 0 2px 10px rgba(40, 167, 69, 0.2);
            border: 1px solid var(--success-color);
        }
        .total-display strong {
            color: var(--primary-color); /* Total amount in primary color */
            margin-left: 5px;
        }

        /* QR Card Grid (Responsive Grid) */
        .qr-bank-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        .qr-bank-card {
            background-color: var(--card-background);
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow-light);
            text-align: center;
            border: 1px solid #ddd;
            transition: all 0.3s ease;
        }
        .qr-bank-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            border-color: var(--secondary-color);
        }
        .qr-bank-card h3 {
            color: var(--primary-color);
            margin-bottom: 20px;
            font-size: 1.4em;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }
        .qr-bank-card img {
            width: 100%;
            max-width: 180px;
            height: auto;
            margin-bottom: 15px;
            border: 5px solid var(--primary-color);
            border-radius: 10px;
            padding: 5px; /* Inner padding for the image */
            background-color: white;
        }
        .qr-bank-card p {
            margin: 8px 0;
            font-size: 1em;
            text-align: left;
            padding-left: 20px;
        }
        .qr-bank-card p strong {
            display: inline-block;
            width: 120px;
            color: var(--secondary-color);
        }
        .qr-bank-card .note {
            font-size: 0.85em;
            color: #999;
            margin-top: 15px;
            border-top: 1px dashed #eee;
            padding-top: 10px;
            text-align: center;
            padding-left: 0;
        }
        
        /* Transaction ID and Button */
        .transaction-id {
            display: inline-flex; /* Use inline-flex to center better */
            justify-content: center;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        .transaction-id span {
            padding: 12px 25px;
            border-radius: 8px;
            background-color: #e6f7ff; /* Light blue background */
            color: var(--primary-color);
            font-size: 1.4em;
            font-weight: 600;
            border: 2px dashed var(--secondary-color);
            cursor: default;
        }
        .btn-confirm {
            display: block;
            padding: 18px 30px;
            max-width: 450px; /* Limit button width for better design */
            margin: 40px auto 0;
            background-color: var(--success-color);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-size: 1.3em;
            font-weight: 700;
            letter-spacing: 0.5px;
            transition: background-color 0.3s ease, transform 0.1s ease;
            border: none;
            cursor: pointer;
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.4);
        }
        .btn-confirm:hover {
            background-color: #1e7e34;
            transform: translateY(-2px);
        }
        
        /* Mobile adjustment */
        @media (max-width: 768px) {
            .qr-bank-grid {
                grid-template-columns: 1fr; /* Stack cards on mobile */
            }
            .payment-box {
                margin: 20px auto;
                padding: 20px;
            }
            .total-display {
                font-size: 1.5em;
            }
            .transaction-id span {
                font-size: 1.1em;
                padding: 10px 20px;
            }
            .btn-confirm {
                width: 100%;
                max-width: none;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>MODERN SHOP8</h1>
            <nav>
                <ul>
                    <li><a href="index.php">ទំព័រដើម</a></li>
                    <li><a href="cart.php">រទេះទិញទំនិញ</a></li>
                    <li><a href="history.php">ប្រវត្តិការទិញ</a></li>
                    <?php if (isset($_SESSION['is_admin']) && $_SESSION['is_admin']): ?>
                        <li><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                        <li><a href="logout.php">ចាកចេញ</a></li>
                    <?php else: ?>
                        <li><a href="admin_login.php">ចូលជាអ្នកគ្រប់គ្រង</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="payment-box">
            <h2>វិធីសាស្រ្តទូទាត់ប្រាក់</h2>
            <p class="payment-info">សូមស្កេន QR Code ណាមួយខាងក្រោម ឬផ្ទេរតាមរយៈលេខគណនី។</p>

            <div class="total-display">
                តម្លៃសរុបដែលត្រូវបង់: 
                <strong>$<?php echo htmlspecialchars(number_format($total_price, 2)); ?></strong>
            </div>

            <!-- QR Code and Bank Card Grid -->
            <?php if (!empty($qr_settings)): ?>
            <div class="qr-bank-grid">
                <?php foreach ($qr_settings as $qr): ?>
                <div class="qr-bank-card">
                    <h3><?php echo htmlspecialchars($qr['bank_name']); ?></h3>
                    
                    <!-- Placeholder/Image for QR Code -->
                    <img src="<?php echo htmlspecialchars($qr['qr_image_url']); ?>" 
                         alt="QR Code for <?php echo htmlspecialchars($qr['bank_name']); ?>"
                         onerror="this.onerror=null;this.src='https://placehold.co/180x180/004c99/ffffff?text=QR+Code';"
                    >

                    <!-- Null Coalescing Operator (?? '') is used here to prevent 'Undefined array key' warnings -->
                    <p><strong>ឈ្មោះគណនី:</strong> <?php echo htmlspecialchars($qr['account_holder_name'] ?? ''); ?></p>
                    <p><strong>លេខគណនី:</strong> <?php echo htmlspecialchars($qr['account_number'] ?? ''); ?></p>
                    <p><strong>លេខទូរស័ព្ទ:</strong> <?php echo htmlspecialchars($qr['phone_number'] ?? ''); ?></p>

                    <p class="note">
                        សូមធានាថាអ្នកផ្ទេរប្រាក់ $<?php echo htmlspecialchars(number_format($total_price, 2)); ?> 
                        និងប្រើ **លេខសម្គាល់ប្រតិបត្តិការ** ខាងក្រោម។
                    </p>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
                <div style="padding: 20px; background-color: #fce4e4; color: #cc0000; border-radius: 8px; margin-bottom: 30px;">
                    <p>⚠️ មិនទាន់មានការកំណត់ QR Code ណាមួយត្រូវបានរកឃើញនៅក្នុងមូលដ្ឋានទិន្នន័យទេ។ សូមចូលទៅកាន់ផ្ទាំងគ្រប់គ្រងដើម្បីបន្ថែម។</p>
                </div>
            <?php endif; ?>

            <div style="margin-top: 20px;">
                <p style="margin-bottom: 10px; font-size: 1.2em; color: var(--text-color);">
                    លេខសម្គាល់ប្រតិបត្តិការ (Ref. ID): 
                </p>
                <!-- DYNAMIC TRANSACTION ID -->
                <div class="transaction-id">
                    <span>
                        <?php echo htmlspecialchars($transaction_id); ?>
                    </span>
                </div>
                <p class="payment-info" style="margin-top: -15px;">
                    សូមប្រើលេខសម្គាល់នេះ <strong>(<?php echo htmlspecialchars($transaction_id); ?>)</strong> នៅក្នុងកំណត់ចំណាំ (Memo) នៃការផ្ទេរប្រាក់របស់អ្នក។
                </p>
                
                <a href="checkout.php" class="btn-confirm">
                    ok 
                </a>
            </div>
        </div>
