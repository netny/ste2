<?php
// admin_contacts.php - ទំព័រសម្រាប់បង្ហាញសារពីទម្រង់ទំនាក់ទំនង (FUN STYLE)
include 'database.php';

// ចាប់ផ្តើម session ប្រសិនបើវាមិនទាន់បានចាប់ផ្តើម
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get the current script name for active link highlighting
$current_page = basename($_SERVER['PHP_SELF']); 

// ពិនិត្យមើលថាតើអ្នកប្រើប្រាស់បានចូលជាអ្នកគ្រប់គ្រងឬអត់
if (!isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: admin_login.php');
    exit;
}

// គ្រប់គ្រងសកម្មភាពលុបសារ
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $contact_id = intval($_GET['delete']);
    
    // លុបសារចេញពីមូលដ្ឋានទិន្នន័យ
    $stmt = $conn->prepare("DELETE FROM contacts WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $contact_id);
        $stmt->execute();
        $stmt->close();
    }

    header('Location: admin_contacts.php');
    exit;
}

// ហៅយកសារទាំងអស់ពីតារាង contacts
$sql = "SELECT * FROM contacts ORDER BY id DESC";
$result = $conn->query($sql);

$messages = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="km">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>គ្រប់គ្រងសារទំនាក់ទំនង</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* ======================================= */
        /* --- GLOBAL & VARIABLE SETUP --- */
        /* ======================================= */
        :root {
            --primary-color: #006d77; /* Teal Blue */
            --secondary-color: #ffd166; /* Yellow/Gold */
            --card-background: #ffffff;
            --border-radius: 8px;
            --shadow-light: 0 4px 6px rgba(0,0,0,0.1);
            --shadow-heavy: 0 8px 15px rgba(0,0,0,0.2);
            --text-color: #333;
            --light-text-color: #666;
            --delete-button-bg: #e63946;
            --accent-blue: #17a2b8;
        }

        body {
            font-family: 'Khmer OS Muol Light', Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: var(--text-color);
        }
        
        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* ======================================= */
        /* --- HEADER & NAVIGATION (FUN/RESPONSIVE) --- */
        /* ======================================= */
        header { background-color: var(--primary-color); padding: 15px 0; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }
        header .navbar {
            display: flex; justify-content: space-between; align-items: center; width: 90%; max-width: 1200px; margin: auto; flex-wrap: wrap; 
        }
        /* Logo Styles */
        .brand-logo { display: flex; align-items: center; gap: 10px; order: 1; }
        .brand-logo img { height: 40px; width: auto; border-radius: 5px; background-color: var(--primary-color); padding: 2px; }
        .brand-text { display: flex; flex-direction: column; color: #fff; line-height: 1.2; }
        .brand-text h1 { font-size: 1.5em; margin: 0; font-weight: bold; }
        .brand-text p { font-size: 0.8em; margin: 0; opacity: 0.8; }
        /* Nav Links */
        header nav ul { list-style: none; display: flex; gap: 20px; margin: 0; padding: 0; order: 3; width: 100%; justify-content: flex-end; }
        header nav ul li a {
            color: #fff; text-decoration: none; font-weight: 500; padding-bottom: 5px; transition: color 0.3s, border-bottom 0.3s;
        }
        header nav ul li a:hover,
        header nav ul li.active-link a { color: var(--secondary-color); border-bottom: 2px solid var(--secondary-color); }
        /* Mobile Toggle */
        .menu-toggle { display: none; cursor: pointer; font-size: 24px; color: #fff; order: 2; }
        
        /* Mobile Menu */
        @media (max-width: 768px) {
            .menu-toggle { display: block; }
            header .navbar ul { display: none; flex-direction: column; order: 4; background-color: #005660; }
            header .navbar ul.open { display: flex; }
            .brand-logo { flex-direction: column; align-items: flex-start; gap: 2px; }
        }

        /* ======================================= */
        /* --- MESSAGE TABLE FUN STYLE --- */
        /* ======================================= */
        .container h2 {
            font-size: 2em;
            color: var(--primary-color);
            border-bottom: 3px solid var(--secondary-color);
            padding-bottom: 10px;
            margin-top: 30px;
            margin-bottom: 30px;
            text-align: center;
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: var(--shadow-heavy); /* Bold shadow */
            background-color: var(--card-background);
            border-radius: 10px;
            overflow: hidden;
        }
        .admin-table th, .admin-table td {
            border: 1px solid #eee;
            padding: 12px 15px;
            text-align: left;
            vertical-align: top;
        }
        .admin-table th {
            background-color: var(--accent-blue); /* Distinct header color */
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }
        .admin-table tbody tr:nth-child(even) {
            background-color: #f8f8f8;
        }
        .admin-table tbody tr:hover {
            background-color: #e0f7fa; /* Fun hover effect */
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .admin-actions a.btn {
            background-color: var(--delete-button-bg);
            color: white;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 50px; /* Pill shape */
            font-weight: bold;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s ease;
        }
        .admin-actions a.btn:hover {
            background-color: #b82333;
            transform: scale(1.05);
        }
        
        .message-content {
            max-height: 80px; /* Limit height for summary view */
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 3; /* Show max 3 lines */
            -webkit-box-orient: vertical;
        }

        /* Responsive Table (Card View) */
        @media (max-width: 768px) {
            .admin-table, .admin-table thead, .admin-table tbody, .admin-table th, .admin-table td, .admin-table tr { 
                display: block; 
            }
            .admin-table thead tr { position: absolute; top: -9999px; left: -9999px; }
            .admin-table tr { border: 1px solid #ccc; margin-bottom: 15px; border-radius: 5px; }
            .admin-table td { 
                border: none; border-bottom: 1px solid #eee; position: relative; 
                padding-left: 50%; text-align: right; 
            }
            .admin-table td:before { 
                position: absolute; top: 50%; left: 10px; width: 45%; 
                content: attr(data-label); font-weight: bold; text-align: left; 
                transform: translateY(-50%);
            }
            
            /* Data Labels */
            .admin-table td:nth-of-type(1):before { content: "លេខសម្គាល់:"; }
            .admin-table td:nth-of-type(2):before { content: "ឈ្មោះ:"; }
            .admin-table td:nth-of-type(3):before { content: "អ៊ីមែល:"; }
            .admin-table td:nth-of-type(4):before { content: "សារ:"; }
            .admin-table td:nth-of-type(5):before { content: "សកម្មភាព:"; }
            
            .admin-actions { text-align: center; padding-left: 10px !important; display: block; border-bottom: none; }
        }
    </style>
</head>
<body>

<header>
    <div class="container navbar">
        <div class="brand-logo">
            <img src="https://i.pinimg.com/736x/c3/e4/fb/c3e4fb0d47ac9271cb777e39428dd590.jpg" alt="Modern Shop8 Logo">
            <div class="brand-text">
                <h1>MODERN SHOP8</h1>
                <p>គ្រប់គ្រងសារ</p> 
            </div>
        </div>
        
        <div class="menu-toggle" onclick="toggleMenu()">
            <i class="fas fa-bars"></i>
        </div>

        <nav>
            <ul id="admin-menu">
                <li class="<?php echo ($current_page == 'admin.php') ? 'active-link' : ''; ?>"><a href="admin.php">ផ្ទាំងគ្រប់គ្រង</a></li>
                <li class="<?php echo ($current_page == 'admin_contacts.php') ? 'active-link' : ''; ?>"><a href="admin_contacts.php">មើលសារ</a></li>
                <li class="<?php echo ($current_page == 'logout.php') ? 'active-link' : ''; ?>"><a href="logout.php">ចាកចេញ</a></li>
            </ul>
        </nav>
    </div>
</header>

<div class="container">
    <h2><i class="fas fa-inbox" style="color: var(--secondary-color);"></i> សារទំនាក់ទំនង</h2>
    
    <?php if (empty($messages)): ?>
        <p style="text-align: center; font-size: 1.2em; color: var(--light-text-color); padding: 40px;">
            <i class="fas fa-box-open"></i> មិនទាន់មានសារទំនាក់ទំនងថ្មីនៅឡើយទេ។
        </p>
    <?php else: ?>
        <table class="admin-table">
            <thead>
                <tr>
                    <th><i class="fas fa-hashtag"></i> ID</th>
                    <th><i class="fas fa-user"></i> ឈ្មោះ</th>
                    <th><i class="fas fa-envelope"></i> អ៊ីមែល</th>
                    <th><i class="fas fa-comment-dots"></i> សារ</th>
                    <th><i class="fas fa-tools"></i> សកម្មភាព</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($messages as $message): ?>
                    <tr>
                        <td data-label="លេខសម្គាល់"><?php echo htmlspecialchars($message['id']); ?></td>
                        <td data-label="ឈ្មោះ"><?php echo htmlspecialchars($message['name']); ?></td>
                        <td data-label="អ៊ីមែល"><?php echo htmlspecialchars($message['email']); ?></td>
                        <td data-label="សារ">
                            <div class="message-content">
                                <?php echo htmlspecialchars($message['message']); ?>
                            </div>
                        </td>
                        <td data-label="សកម្មភាព" class="admin-actions">
                            <a href="admin_contacts.php?delete=<?php echo htmlspecialchars($message['id']); ?>" class="btn btn-remove" onclick="return confirm('តើអ្នកពិតជាចង់លុបសារនេះមែនទេ?');">
                                <i class="fas fa-trash-alt"></i> លុប
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    
    <div style="text-align: center; margin-top: 30px;">
        <a href="admin.php" class="btn btn-primary" style="background-color: var(--primary-color); color: white; padding: 10px 20px; text-decoration: none; border-radius: 50px;">
            <i class="fas fa-arrow-left"></i> ត្រលប់ទៅផ្ទាំងគ្រប់គ្រង
        </a>
    </div>
</div>

<script>
    function toggleMenu() {
        var menu = document.getElementById('admin-menu');
        menu.classList.toggle('open');
    }
</script>
</body>
</html>
<?php
// បិទការតភ្ជាប់បន្ទាប់ពីការដំណើរការ script ទាំងមូល
if (isset($conn)) {
    $conn->close();
}
?>